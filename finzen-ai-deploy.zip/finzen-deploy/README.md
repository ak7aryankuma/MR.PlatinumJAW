# FinZen AI

A personal finance dashboard prototype — dark neon glassmorphic theme, full CRUD for income/expenses/investments/goals, budget planner, financial health score, reports with Excel/CSV/PDF export, finance calendar, gamification, and an AI Advisor (currently rule-based, see note below).

## Running locally

```bash
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`).

## Deploying — GitHub + Netlify

### 1. Push this project to GitHub

If you don't already have a repo:

1. Go to [github.com/new](https://github.com/new)
2. Name it (e.g. `finzen-ai`), leave it **Public** or **Private** as you prefer, don't initialize with a README (you already have one)
3. Click **Create repository**
4. GitHub will show you a page with commands — back in your terminal, from this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/finzen-ai.git
git push -u origin main
```

(Replace `YOUR_USERNAME` and the repo name with your actual values from the GitHub page.)

### 2. Connect Netlify to your GitHub repo

1. Go to [app.netlify.com](https://app.netlify.com) and log in (or sign up — it's free)
2. Click **Add new site → Import an existing project**
3. Choose **GitHub** and authorize Netlify if asked
4. Select your `finzen-ai` repo from the list
5. Netlify will auto-detect the build settings from `netlify.toml` in this project:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Click **Deploy site**

That's it — Netlify will install dependencies, run the build, and give you a live URL like `random-name-123.netlify.app` within a minute or two.

### 3. Optional: custom domain / site name

In the Netlify dashboard for your site: **Site settings → Change site name** lets you pick a nicer subdomain (e.g. `finzen-ai.netlify.app`, if available). You can also add a custom domain under **Domain management** if you own one.

### 4. Future updates

Any time you `git push` to the `main` branch, Netlify automatically rebuilds and redeploys. No manual redeploy step needed.

## Notes on the AI Advisor

The AI Advisor chat currently runs on a **rule-based response engine** (see `generateAdvisorReply` in `src/FinZenApp.jsx`) — it pattern-matches your question and computes real answers from your actual income/expense/investment/goal data, but it is not calling a live language model. This was a deliberate choice to avoid putting an API key in client-side code, which would expose it to anyone who opens the browser dev tools.

If you want real AI responses later, the right approach is a small serverless function (Netlify Functions work well here) that holds your API key server-side and proxies requests to Anthropic's API — happy to help you build that whenever you're ready.
