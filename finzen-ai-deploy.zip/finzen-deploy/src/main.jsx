import React from "react";
import ReactDOM from "react-dom/client";
import FinZenApp from "./FinZenApp.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FinZenApp />
  </React.StrictMode>
);
