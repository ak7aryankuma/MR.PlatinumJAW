import React, { useState, useMemo } from "react";
import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from "recharts";
import {
  LayoutDashboard, ArrowDownCircle, ArrowUpCircle, TrendingUp, Target,
  Wallet, Bell, Settings, User, Search, Plus, Pencil, Trash2, X,
  ChevronDown, Filter, IndianRupee, Sparkles, Flame, Award, Calendar,
  ArrowUp, ArrowDown, PiggyBank, Landmark, Bot, SendHorizontal, AlertTriangle,
  CheckCircle2, ClipboardList, RotateCcw, Activity, FileDown, FileSpreadsheet,
  FileText, ShieldCheck, ChevronLeft, ChevronRight, Repeat, Trophy, Star,
  Medal, Zap, BellRing, Info, CircleAlert, Mail, Lock, Eye, EyeOff, LogOut,
  Camera, Briefcase, Cake, Sliders, Smartphone, Globe, Moon, Sun, KeyRound,
  ArrowRight, Check
} from "lucide-react";

/* ---------------------------------- THEME ---------------------------------- */
const C = {
  bg: "#000000",
  surface: "#121212",
  surface2: "#1A1A1A",
  border: "rgba(255,255,255,0.08)",
  borderHover: "rgba(0,255,179,0.35)",
  accent: "#00FFB3",
  highlight: "#7C3AED",
  success: "#22C55E",
  danger: "#EF4444",
  text: "#F4F4F5",
  textMute: "#8B8B92",
  textFaint: "#5A5A62",
};

const CATEGORY_COLORS = {
  Food: "#00FFB3", Travel: "#7C3AED", Shopping: "#F472B6", Rent: "#EF4444",
  Bills: "#FACC15", Healthcare: "#22D3EE", Education: "#818CF8",
  Entertainment: "#FB923C", Other: "#8B8B92",
};

const fmt = (n, currency = "INR") => {
  const symbols = { INR: "₹", USD: "$", EUR: "€", GBP: "£" };
  const v = Math.round(n);
  return symbols[currency] + Math.abs(v).toLocaleString("en-IN") + (n < 0 ? "" : "");
};
const signedFmt = (n, currency = "INR") => (n < 0 ? "-" : "") + fmt(n, currency);

/* ------------------------------ SEED DATA ------------------------------ */
const seedIncome = [
  { id: "i1", source: "Acme Corp", amount: 95000, date: "2026-06-01", category: "Salary", desc: "Monthly salary credit" },
  { id: "i2", source: "Freelance UI work", amount: 18000, date: "2026-06-05", category: "Freelance", desc: "Logo + landing page for a D2C brand" },
  { id: "i3", source: "Dividend - HDFC", amount: 1200, date: "2026-06-10", category: "Dividend", desc: "Quarterly dividend payout" },
  { id: "i4", source: "Acme Corp", amount: 95000, date: "2026-05-01", category: "Salary", desc: "Monthly salary credit" },
  { id: "i5", source: "Rental - 2BHK Indiranagar", amount: 22000, date: "2026-05-03", category: "Rental", desc: "Tenant rent payment" },
  { id: "i6", source: "Freelance copywriting", amount: 9000, date: "2026-05-14", category: "Freelance", desc: "Blog content for SaaS client" },
  { id: "i7", source: "Acme Corp", amount: 92000, date: "2026-04-01", category: "Salary", desc: "Monthly salary credit" },
  { id: "i8", source: "Side project sale", amount: 14000, date: "2026-04-18", category: "Business", desc: "Sold a Notion template pack" },
];

const seedExpenses = [
  { id: "e1", name: "Zomato orders", amount: 4200, date: "2026-06-12", category: "Food", desc: "Weekday lunches and late-night cravings" },
  { id: "e2", name: "Flight to Goa", amount: 8600, date: "2026-06-08", category: "Travel", desc: "Weekend trip with friends" },
  { id: "e3", name: "House rent", amount: 28000, date: "2026-06-01", category: "Rent", desc: "Monthly rent, 2BHK Koramangala" },
  { id: "e4", name: "Electricity bill", amount: 2100, date: "2026-06-03", category: "Bills", desc: "BESCOM monthly bill" },
  { id: "e5", name: "Amazon haul", amount: 5400, date: "2026-06-15", category: "Shopping", desc: "New headphones and a desk lamp" },
  { id: "e6", name: "Gym membership", amount: 1800, date: "2026-06-01", category: "Healthcare", desc: "Monthly gym renewal" },
  { id: "e7", name: "Netflix + Spotify", amount: 900, date: "2026-06-01", category: "Entertainment", desc: "Subscription renewals" },
  { id: "e8", name: "Swiggy orders", amount: 3800, date: "2026-05-20", category: "Food", desc: "Weekend orders" },
  { id: "e9", name: "House rent", amount: 28000, date: "2026-05-01", category: "Rent", desc: "Monthly rent, 2BHK Koramangala" },
  { id: "e10", name: "Online course - System Design", amount: 6000, date: "2026-05-11", category: "Education", desc: "Upskilling course" },
  { id: "e11", name: "Diwali shopping", amount: 9200, date: "2026-05-22", category: "Shopping", desc: "Clothes and gifts" },
  { id: "e12", name: "Mobile + WiFi bill", amount: 1700, date: "2026-05-04", category: "Bills", desc: "Airtel postpaid + broadband" },
  { id: "e13", name: "House rent", amount: 28000, date: "2026-04-01", category: "Rent", desc: "Monthly rent, 2BHK Koramangala" },
  { id: "e14", name: "Doctor visit", amount: 1500, date: "2026-04-09", category: "Healthcare", desc: "General checkup" },
  { id: "e15", name: "Food delivery", amount: 4600, date: "2026-04-19", category: "Food", desc: "Various orders through the month" },
];

const seedInvestments = [
  { id: "v1", name: "Nifty 50 Index Fund", type: "Mutual Funds", invested: 120000, current: 142500, purchaseDate: "2024-02-10", notes: "Core long-term SIP holding" },
  { id: "v2", name: "HDFC Bank", type: "Stocks", invested: 45000, current: 51200, purchaseDate: "2024-08-22", notes: "Banking sector bet" },
  { id: "v3", name: "Bitcoin", type: "Crypto", invested: 30000, current: 41800, purchaseDate: "2023-11-05", notes: "Small speculative allocation" },
  { id: "v4", name: "SIP - Parag Parikh Flexi Cap", type: "SIPs", invested: 60000, current: 71400, purchaseDate: "2023-06-01", notes: "Monthly SIP of ₹5,000" },
  { id: "v5", name: "Sovereign Gold Bond", type: "Gold", invested: 25000, current: 29100, purchaseDate: "2022-12-15", notes: "Inflation hedge" },
  { id: "v6", name: "RBI Floating Rate Bond", type: "Bonds", invested: 50000, current: 53600, purchaseDate: "2024-01-20", notes: "Low-risk fixed income" },
  { id: "v7", name: "Bank FD - SBI", type: "Fixed Deposit", invested: 100000, current: 107800, purchaseDate: "2024-03-01", notes: "1-year FD at 7.1%" },
];

const seedGoals = [
  { id: "g1", name: "Emergency Fund", target: 300000, saved: 210000, deadline: "2026-12-31" },
  { id: "g2", name: "Buy a Car", target: 800000, saved: 240000, deadline: "2027-06-30" },
  { id: "g3", name: "Goa Vacation", target: 60000, saved: 48000, deadline: "2026-09-15" },
  { id: "g4", name: "House Down Payment", target: 2500000, saved: 410000, deadline: "2029-01-01" },
];

const netWorthTrend = [
  { month: "Jan", value: 612000 }, { month: "Feb", value: 638000 },
  { month: "Mar", value: 661000 }, { month: "Apr", value: 679000 },
  { month: "May", value: 705000 }, { month: "Jun", value: 728000 },
];

const cashFlowTrend = [
  { month: "Jan", income: 102000, expenses: 68000 },
  { month: "Feb", income: 98000, expenses: 71000 },
  { month: "Mar", income: 105000, expenses: 64000 },
  { month: "Apr", income: 106000, expenses: 69500 },
  { month: "May", income: 126000, expenses: 70500 },
  { month: "Jun", income: 114200, expenses: 53000 },
];

const seedRecurring = [
  { id: "r1", name: "House rent", type: "expense", category: "Rent", amount: 28000, frequency: "Monthly", nextDate: "2026-07-01" },
  { id: "r2", name: "Salary - Acme Corp", type: "income", category: "Salary", amount: 95000, frequency: "Monthly", nextDate: "2026-07-01" },
  { id: "r3", name: "Netflix + Spotify", type: "expense", category: "Entertainment", amount: 900, frequency: "Monthly", nextDate: "2026-07-01" },
  { id: "r4", name: "SIP - Parag Parikh Flexi Cap", type: "investment", category: "SIPs", amount: 5000, frequency: "Monthly", nextDate: "2026-07-05" },
  { id: "r5", name: "Gym membership", type: "expense", category: "Healthcare", amount: 1800, frequency: "Monthly", nextDate: "2026-07-01" },
  { id: "r6", name: "Mobile + WiFi bill", type: "expense", category: "Bills", amount: 1700, frequency: "Monthly", nextDate: "2026-07-04" },
];

const calendarEvents2026_06 = [
  { date: "2026-06-01", label: "Salary credit", type: "income" },
  { date: "2026-06-01", label: "Rent due", type: "bill" },
  { date: "2026-06-01", label: "Netflix + Spotify", type: "bill" },
  { date: "2026-06-03", label: "Electricity bill", type: "bill" },
  { date: "2026-06-05", label: "SIP debit", type: "sip" },
  { date: "2026-06-10", label: "Dividend credit", type: "income" },
];

const seedBadges = [
  { id: "b1", name: "Budget Master", desc: "Stayed under budget in 4+ categories this month", icon: "ClipboardList", earned: true },
  { id: "b2", name: "Investment Guru", desc: "Portfolio ROI above 10%", icon: "TrendingUp", earned: true },
  { id: "b3", name: "Saving Champion", desc: "Hit a savings goal milestone", icon: "PiggyBank", earned: true },
  { id: "b4", name: "Streak Keeper", desc: "Logged expenses for 7 days straight", icon: "Flame", earned: false },
  { id: "b5", name: "Goal Crusher", desc: "Completed a savings goal fully", icon: "Trophy", earned: false },
  { id: "b6", name: "Diversifier", desc: "Hold 5+ investment types", icon: "Star", earned: true },
];


function GlassCard({ children, className = "", glow = false, style = {} }) {
  return (
    <div
      className={className}
      style={{
        background: "rgba(18,18,18,0.7)",
        backdropFilter: "blur(16px)",
        WebkitBackdropFilter: "blur(16px)",
        border: `1px solid ${glow ? "rgba(0,255,179,0.25)" : C.border}`,
        borderRadius: 18,
        boxShadow: glow ? "0 0 40px -10px rgba(0,255,179,0.25)" : "0 4px 30px rgba(0,0,0,0.3)",
        transition: "border-color 0.25s ease, transform 0.2s ease",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function IconBadge({ icon, color }) {
  return (
    <div
      style={{
        width: 38, height: 38, borderRadius: 12, display: "flex",
        alignItems: "center", justifyContent: "center",
        background: `${color}1A`, color, flexShrink: 0,
      }}
    >
      {icon}
    </div>
  );
}

function Pill({ children, color }) {
  return (
    <span
      style={{
        fontSize: 12, fontWeight: 600, padding: "3px 10px", borderRadius: 999,
        background: `${color}1A`, color, border: `1px solid ${color}33`,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}

function NeonButton({ children, onClick, variant = "primary", style = {}, type = "button" }) {
  const base = {
    primary: { background: C.accent, color: "#000", border: "none" },
    ghost: { background: "transparent", color: C.text, border: `1px solid ${C.border}` },
    violet: { background: C.highlight, color: "#fff", border: "none" },
    danger: { background: "transparent", color: C.danger, border: `1px solid ${C.danger}44` },
  }[variant];
  return (
    <button
      type={type}
      onClick={onClick}
      style={{
        ...base,
        padding: "9px 16px", borderRadius: 12, fontSize: 13.5, fontWeight: 600,
        cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6,
        transition: "transform 0.12s ease, opacity 0.15s ease",
        ...style,
      }}
      onMouseDown={(e) => (e.currentTarget.style.transform = "scale(0.97)")}
      onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
    >
      {children}
    </button>
  );
}

function Input({ label, ...props }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
      {label}
      <input
        {...props}
        style={{
          background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10,
          padding: "10px 12px", color: C.text, fontSize: 14, outline: "none",
          fontFamily: "inherit",
        }}
        onFocus={(e) => (e.target.style.borderColor = C.accent)}
        onBlur={(e) => (e.target.style.borderColor = C.border)}
      />
    </label>
  );
}

function Select({ label, options, ...props }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
      {label}
      <select
        {...props}
        style={{
          background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10,
          padding: "10px 12px", color: C.text, fontSize: 14, outline: "none",
          fontFamily: "inherit", appearance: "none",
        }}
      >
        {options.map((o) => (
          <option key={o} value={o} style={{ background: "#0A0A0A" }}>{o}</option>
        ))}
      </select>
    </label>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div
      style={{
        position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 50, padding: 20,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: 460, background: "#101010",
          border: `1px solid ${C.border}`, borderRadius: 20, padding: 24,
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)", maxHeight: "85vh", overflowY: "auto",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: C.text, fontFamily: "'Space Grotesk', sans-serif" }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}>
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ProgressBar({ pct, color = C.accent }) {
  return (
    <div style={{ height: 8, background: "#1E1E1E", borderRadius: 999, overflow: "hidden" }}>
      <div style={{
        height: "100%", width: `${Math.min(100, pct)}%`, background: color,
        borderRadius: 999, transition: "width 0.5s ease",
        boxShadow: `0 0 12px ${color}88`,
      }} />
    </div>
  );
}

/* ------------------------------ USER SEED DATA ------------------------------ */
const seedUser = {
  fullName: "Aryan Raj",
  username: "aryan.raj",
  email: "aryan.raj@example.com",
  age: 28,
  occupation: "Product Analyst",
  monthlyIncomeGoal: 120000,
  financialGoal: "Buy a house in 5 years",
  riskProfile: "Moderate",
  avatarInitials: "AR",
};

/* ------------------------------ NAV ------------------------------ */
const NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={18} /> },
  { key: "income", label: "Income", icon: <ArrowDownCircle size={18} /> },
  { key: "expenses", label: "Expenses", icon: <ArrowUpCircle size={18} /> },
  { key: "investments", label: "Investments", icon: <TrendingUp size={18} /> },
  { key: "goals", label: "Savings Goals", icon: <Target size={18} /> },
  { key: "budget", label: "Budget Planner", icon: <ClipboardList size={18} /> },
  { key: "calendar", label: "Finance Calendar", icon: <Calendar size={18} /> },
  { key: "health", label: "Health Score", icon: <Activity size={18} /> },
  { key: "reports", label: "Reports", icon: <FileText size={18} /> },
  { key: "rewards", label: "Rewards", icon: <Trophy size={18} /> },
  { key: "advisor", label: "AI Advisor", icon: <Bot size={18} /> },
];

const ACCOUNT_NAV_ITEMS = [
  { key: "profile", label: "Profile", icon: <User size={18} /> },
  { key: "settings", label: "Settings", icon: <Settings size={18} /> },
];

function Sidebar({ active, setActive, currency, setCurrency, user, onLogout }) {
  return (
    <div
      style={{
        width: 232, flexShrink: 0, background: "#0A0A0A",
        borderRight: `1px solid ${C.border}`, display: "flex",
        flexDirection: "column", padding: "22px 16px", gap: 4, overflowY: "auto",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 8px 26px" }}>
        <div style={{
          width: 34, height: 34, borderRadius: 10, background: `linear-gradient(135deg, ${C.accent}, ${C.highlight})`,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Sparkles size={18} color="#000" />
        </div>
        <div>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 16, color: C.text, letterSpacing: -0.3 }}>FinZen</div>
          <div style={{ fontSize: 10, color: C.accent, fontWeight: 600, letterSpacing: 1 }}>AI</div>
        </div>
      </div>

      {NAV_ITEMS.map((item) => {
        const isActive = active === item.key;
        return (
          <button
            key={item.key}
            onClick={() => setActive(item.key)}
            style={{
              display: "flex", alignItems: "center", gap: 11, padding: "10px 12px",
              borderRadius: 12, border: "none", cursor: "pointer", textAlign: "left",
              background: isActive ? "rgba(0,255,179,0.1)" : "transparent",
              color: isActive ? C.accent : C.textMute,
              fontSize: 13.5, fontWeight: isActive ? 700 : 500,
              fontFamily: "inherit", transition: "all 0.15s ease",
            }}
            onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
            onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.background = "transparent"; }}
          >
            {item.icon}
            {item.label}
          </button>
        );
      })}

      <div style={{ height: 1, background: C.border, margin: "10px 4px" }} />

      {ACCOUNT_NAV_ITEMS.map((item) => {
        const isActive = active === item.key;
        return (
          <button
            key={item.key}
            onClick={() => setActive(item.key)}
            style={{
              display: "flex", alignItems: "center", gap: 11, padding: "10px 12px",
              borderRadius: 12, border: "none", cursor: "pointer", textAlign: "left",
              background: isActive ? "rgba(124,58,237,0.12)" : "transparent",
              color: isActive ? C.highlight : C.textMute,
              fontSize: 13.5, fontWeight: isActive ? 700 : 500,
              fontFamily: "inherit", transition: "all 0.15s ease",
            }}
            onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
            onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.background = "transparent"; }}
          >
            {item.icon}
            {item.label}
          </button>
        );
      })}

      <div style={{ flex: 1 }} />

      <div style={{ padding: "0 12px 8px", display: "flex", flexDirection: "column", gap: 8 }}>
        <span style={{ fontSize: 11, color: C.textFaint, fontWeight: 600, letterSpacing: 0.5 }}>CURRENCY</span>
        <select
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
          style={{
            background: "#141414", border: `1px solid ${C.border}`, borderRadius: 10,
            padding: "8px 10px", color: C.text, fontSize: 13, fontFamily: "inherit", outline: "none",
          }}
        >
          {["INR", "USD", "EUR", "GBP"].map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <button
        onClick={() => setActive("profile")}
        style={{
          display: "flex", alignItems: "center", gap: 10, padding: "12px",
          borderRadius: 12, border: `1px solid ${C.border}`, marginTop: 6,
          background: "transparent", cursor: "pointer", width: "100%", textAlign: "left",
        }}
      >
        <div style={{
          width: 32, height: 32, borderRadius: "50%", background: C.highlight,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 12, fontWeight: 700, color: "#fff", flexShrink: 0,
        }}>{user.avatarInitials}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.fullName}</div>
          <div style={{ fontSize: 10.5, color: C.textFaint }}>{user.riskProfile} risk</div>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onLogout(); }}
          title="Log out"
          style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer", padding: 4, flexShrink: 0 }}
        >
          <LogOut size={14} />
        </button>
      </button>
    </div>
  );
}

function notificationsFor(expenses, goals, investments) {
  const notifs = [];
  const foodSpend = expenses.filter((e) => e.category === "Food" && e.date.startsWith("2026-06")).reduce((s, e) => s + e.amount, 0);
  if (foodSpend > 4000) notifs.push({ icon: <AlertTriangle size={15} color={C.danger} />, text: `Food spending has crossed ${fmt(4000)} this month`, color: C.danger });
  goals.forEach((g) => {
    const pct = (g.saved / g.target) * 100;
    if (pct >= 75 && pct < 100) notifs.push({ icon: <Target size={15} color={C.accent} />, text: `"${g.name}" is ${pct.toFixed(0)}% funded — almost there`, color: C.accent });
  });
  const bestInvestment = [...investments].sort((a, b) => (b.current - b.invested) / b.invested - (a.current - a.invested) / a.invested)[0];
  if (bestInvestment) {
    const roi = ((bestInvestment.current - bestInvestment.invested) / bestInvestment.invested) * 100;
    if (roi > 15) notifs.push({ icon: <TrendingUp size={15} color={C.success} />, text: `${bestInvestment.name} is up ${roi.toFixed(0)}% — strong performer`, color: C.success });
  }
  notifs.push({ icon: <Info size={15} color={C.highlight} />, text: "Your June monthly report is ready to view", color: C.highlight });
  return notifs;
}

function NotificationsBell({ expenses, goals, investments }) {
  const [open, setOpen] = useState(false);
  const notifs = useMemo(() => notificationsFor(expenses, goals, investments), [expenses, goals, investments]);

  return (
    <div style={{ position: "relative" }}>
      <button onClick={() => setOpen((o) => !o)} style={{
        width: 38, height: 38, borderRadius: 12, border: `1px solid ${C.border}`,
        background: "transparent", color: C.textMute, cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center", position: "relative",
      }}>
        <Bell size={17} />
        {notifs.length > 0 && (
          <span style={{
            position: "absolute", top: 8, right: 9, width: 7, height: 7,
            borderRadius: "50%", background: C.accent, boxShadow: `0 0 6px ${C.accent}`,
          }} />
        )}
      </button>
      {open && (
        <>
          <div onClick={() => setOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 40 }} />
          <div style={{
            position: "absolute", top: 46, right: 0, width: 320, background: "#101010",
            border: `1px solid ${C.border}`, borderRadius: 16, padding: 8, zIndex: 41,
            boxShadow: "0 20px 50px rgba(0,0,0,0.5)",
          }}>
            <div style={{ padding: "10px 12px", fontSize: 12.5, fontWeight: 700, color: C.text, display: "flex", alignItems: "center", gap: 8 }}>
              <BellRing size={14} color={C.accent} /> Smart notifications
            </div>
            {notifs.map((n, i) => (
              <div key={i} style={{ display: "flex", gap: 10, padding: "10px 12px", borderRadius: 10 }}>
                {n.icon}
                <span style={{ fontSize: 12.5, color: C.textMute, lineHeight: 1.4 }}>{n.text}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function Topbar({ title, subtitle, expenses, goals, investments }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "20px 32px", borderBottom: `1px solid ${C.border}`,
    }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.text, fontFamily: "'Space Grotesk', sans-serif", letterSpacing: -0.3 }}>{title}</h1>
        {subtitle && <p style={{ margin: "4px 0 0", fontSize: 13, color: C.textMute }}>{subtitle}</p>}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <NotificationsBell expenses={expenses} goals={goals} investments={investments} />
        <button style={{
          width: 38, height: 38, borderRadius: 12, border: `1px solid ${C.border}`,
          background: "transparent", color: C.textMute, cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Settings size={17} />
        </button>
      </div>
    </div>
  );
}

/* ------------------------------ DASHBOARD ------------------------------ */
function KpiCard({ label, value, icon, color, trend, glow, currency }) {
  return (
    <GlassCard glow={glow} style={{ padding: "18px 20px", flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, fontWeight: 600, marginBottom: 8 }}>{label}</div>
          <div style={{
            fontSize: 22, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
          }}>
            {fmt(value, currency)}
          </div>
          {trend !== undefined && (
            <div style={{
              display: "flex", alignItems: "center", gap: 3, marginTop: 8, fontSize: 12, fontWeight: 600,
              color: trend >= 0 ? C.success : C.danger,
            }}>
              {trend >= 0 ? <ArrowUp size={13} /> : <ArrowDown size={13} />}
              {Math.abs(trend)}% vs last month
            </div>
          )}
        </div>
        <IconBadge icon={icon} color={color} />
      </div>
    </GlassCard>
  );
}

function ChartCard({ title, children, height = 260 }) {
  return (
    <GlassCard style={{ padding: "20px 20px 12px", flex: 1, minWidth: 320 }}>
      <div style={{ fontSize: 14, fontWeight: 700, color: C.text, marginBottom: 14 }}>{title}</div>
      <div style={{ width: "100%", height }}>{children}</div>
    </GlassCard>
  );
}

const tooltipStyle = {
  background: "#181818", border: `1px solid ${C.border}`, borderRadius: 10,
  fontSize: 12.5, color: C.text, padding: "8px 12px",
};

function Dashboard({ income, expenses, investments, goals, currency }) {
  const totalIncome = income.reduce((s, i) => s + i.amount, 0);
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const totalInvested = investments.reduce((s, v) => s + v.invested, 0);
  const totalCurrentVal = investments.reduce((s, v) => s + v.current, 0);
  const totalSavings = goals.reduce((s, g) => s + g.saved, 0);
  const netWorth = totalCurrentVal + totalSavings + (totalIncome - totalExpenses);
  const cashFlow = totalIncome - totalExpenses;

  const monthlyByCategory = useMemo(() => {
    const map = {};
    expenses.forEach((e) => { map[e.category] = (map[e.category] || 0) + e.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const incomeVsExpense = useMemo(() => {
    const map = {};
    [...income.map(i => ({ ...i, sign: 1 })), ...expenses.map(e => ({ ...e, sign: -1 }))].forEach((t) => {
      const m = t.date.slice(0, 7);
      map[m] = map[m] || { month: m, income: 0, expenses: 0 };
      if (t.sign === 1) map[m].income += t.amount; else map[m].expenses += t.amount;
    });
    return Object.values(map).sort((a, b) => a.month.localeCompare(b.month));
  }, [income, expenses]);

  const investGrowth = investments.map((v) => ({ name: v.name.split(" ")[0], invested: v.invested, current: v.current }));

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label="Total income" value={totalIncome} icon={<ArrowDownCircle size={18} />} color={C.success} trend={8.4} currency={currency} />
        <KpiCard label="Total expenses" value={totalExpenses} icon={<ArrowUpCircle size={18} />} color={C.danger} trend={-3.1} currency={currency} />
        <KpiCard label="Monthly cash flow" value={cashFlow} icon={<Wallet size={18} />} color={C.highlight} currency={currency} />
        <KpiCard label="Net worth" value={netWorth} icon={<Landmark size={18} />} color={C.accent} trend={5.2} glow currency={currency} />
      </div>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label="Total savings" value={totalSavings} icon={<PiggyBank size={18} />} color={C.success} currency={currency} />
        <KpiCard label="Total investments" value={totalCurrentVal} icon={<TrendingUp size={18} />} color={C.highlight} trend={11.6} currency={currency} />
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <ChartCard title="Income vs expenses">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={incomeVsExpense}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E1E1E" vertical={false} />
              <XAxis dataKey="month" stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Bar dataKey="income" fill={C.accent} radius={[6, 6, 0, 0]} />
              <Bar dataKey="expenses" fill={C.danger} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Net worth trend">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={netWorthTrend}>
              <defs>
                <linearGradient id="nw" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={C.accent} stopOpacity={0.4} />
                  <stop offset="100%" stopColor={C.accent} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E1E1E" vertical={false} />
              <XAxis dataKey="month" stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Area type="monotone" dataKey="value" stroke={C.accent} fill="url(#nw)" strokeWidth={2.5} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <ChartCard title="Expense breakdown">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={monthlyByCategory} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
                {monthlyByCategory.map((entry) => (
                  <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || "#8B8B92"} stroke="none" />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Legend wrapperStyle={{ fontSize: 11.5, color: C.textMute }} iconType="circle" />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Investment growth">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={investGrowth} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E1E1E" horizontal={false} />
              <XAxis type="number" stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <YAxis type="category" dataKey="name" stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} width={80} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Bar dataKey="invested" fill="#3A3A3A" radius={[0, 6, 6, 0]} barSize={10} />
              <Bar dataKey="current" fill={C.highlight} radius={[0, 6, 6, 0]} barSize={10} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

/* ------------------------------ INCOME MODULE ------------------------------ */
const INCOME_CATEGORIES = ["Salary", "Freelance", "Business", "Rental", "Dividend", "Other"];
const EXPENSE_CATEGORIES = ["Food", "Travel", "Shopping", "Rent", "Bills", "Healthcare", "Education", "Entertainment", "Other"];

function TransactionForm({ kind, initial, onSave, onClose, currency }) {
  const categories = kind === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  const [form, setForm] = useState(initial || {
    [kind === "income" ? "source" : "name"]: "", amount: "", date: new Date().toISOString().slice(0, 10),
    category: categories[0], desc: "",
  });
  const nameKey = kind === "income" ? "source" : "name";

  return (
    <form
      onSubmit={(e) => { e.preventDefault(); onSave({ ...form, amount: Number(form.amount) }); }}
      style={{ display: "flex", flexDirection: "column", gap: 14 }}
    >
      <Input label={kind === "income" ? "Income source" : "Expense name"} required value={form[nameKey]}
        onChange={(e) => setForm({ ...form, [nameKey]: e.target.value })} placeholder={kind === "income" ? "e.g. Acme Corp salary" : "e.g. Grocery run"} />
      <div style={{ display: "flex", gap: 12 }}>
        <div style={{ flex: 1 }}>
          <Input label={`Amount (${currency})`} type="number" required min="0" value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0" />
        </div>
        <div style={{ flex: 1 }}>
          <Input label="Date" type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        </div>
      </div>
      <Select label="Category" options={categories} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
      <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
        Description
        <textarea value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} rows={2}
          placeholder="A short note about this transaction"
          style={{ background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10, padding: "10px 12px", color: C.text, fontSize: 14, outline: "none", fontFamily: "inherit", resize: "vertical" }} />
      </label>
      <div style={{ display: "flex", gap: 10, marginTop: 6, justifyContent: "flex-end" }}>
        <NeonButton variant="ghost" onClick={onClose}>Cancel</NeonButton>
        <NeonButton type="submit" variant={kind === "income" ? "primary" : "violet"}>
          {initial ? "Save changes" : "Add entry"}
        </NeonButton>
      </div>
    </form>
  );
}

function TransactionTable({ kind, rows, onEdit, onDelete, currency }) {
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const categories = kind === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  const nameKey = kind === "income" ? "source" : "name";

  const filtered = rows
    .filter((r) => (categoryFilter === "All" ? true : r.category === categoryFilter))
    .filter((r) => r[nameKey].toLowerCase().includes(search.toLowerCase()) || r.desc.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.date.localeCompare(a.date));

  const color = kind === "income" ? C.success : C.danger;

  return (
    <GlassCard style={{ padding: 20 }}>
      <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
        <div style={{ position: "relative", flex: "1 1 220px" }}>
          <Search size={15} style={{ position: "absolute", left: 12, top: 11, color: C.textFaint }} />
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search ${kind}...`}
            style={{
              width: "100%", background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10,
              padding: "9px 12px 9px 34px", color: C.text, fontSize: 13.5, outline: "none", fontFamily: "inherit",
              boxSizing: "border-box",
            }}
          />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Filter size={14} color={C.textFaint} />
          <select
            value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}
            style={{ background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10, padding: "9px 10px", color: C.text, fontSize: 13, fontFamily: "inherit", outline: "none" }}
          >
            <option value="All">All categories</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: `1px solid ${C.border}` }}>
              {[kind === "income" ? "Source" : "Name", "Category", "Date", "Description", "Amount", ""].map((h) => (
                <th key={h} style={{ textAlign: h === "Amount" ? "right" : "left", padding: "0 10px 10px", fontSize: 11.5, color: C.textFaint, fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((row) => (
              <tr key={row.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                <td style={{ padding: "12px 10px", fontSize: 13.5, color: C.text, fontWeight: 600 }}>{row[nameKey]}</td>
                <td style={{ padding: "12px 10px" }}><Pill color={CATEGORY_COLORS[row.category] || C.highlight}>{row.category}</Pill></td>
                <td style={{ padding: "12px 10px", fontSize: 13, color: C.textMute, whiteSpace: "nowrap" }}>{row.date}</td>
                <td style={{ padding: "12px 10px", fontSize: 13, color: C.textMute, maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{row.desc}</td>
                <td style={{ padding: "12px 10px", fontSize: 13.5, fontWeight: 700, color, textAlign: "right", fontFamily: "'JetBrains Mono', monospace", whiteSpace: "nowrap" }}>
                  {kind === "income" ? "+" : "-"}{fmt(row.amount, currency)}
                </td>
                <td style={{ padding: "12px 10px" }}>
                  <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                    <button onClick={() => onEdit(row)} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Pencil size={14} /></button>
                    <button onClick={() => onDelete(row.id)} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={6} style={{ padding: "30px 10px", textAlign: "center", color: C.textFaint, fontSize: 13 }}>No {kind} entries match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </GlassCard>
  );
}

function IncomeExpenseModule({ kind, rows, setRows, currency }) {
  const [modal, setModal] = useState(null); // null | "new" | row object

  const handleSave = (data) => {
    if (modal && modal !== "new") {
      setRows(rows.map((r) => (r.id === modal.id ? { ...r, ...data } : r)));
    } else {
      setRows([{ id: `${kind[0]}${Date.now()}`, ...data }, ...rows]);
    }
    setModal(null);
  };

  const total = rows.reduce((s, r) => s + r.amount, 0);
  const thisMonth = rows.filter((r) => r.date.startsWith("2026-06")).reduce((s, r) => s + r.amount, 0);
  const color = kind === "income" ? C.success : C.danger;

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label={`Total ${kind}`} value={total} icon={kind === "income" ? <ArrowDownCircle size={18} /> : <ArrowUpCircle size={18} />} color={color} currency={currency} />
        <KpiCard label="This month (Jun)" value={thisMonth} icon={<Calendar size={18} />} color={C.highlight} currency={currency} />
        <KpiCard label="Number of entries" value={rows.length} icon={<Wallet size={18} />} color={C.accent} currency="" />
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <NeonButton variant={kind === "income" ? "primary" : "violet"} onClick={() => setModal("new")}>
          <Plus size={15} /> Add {kind === "income" ? "income" : "expense"}
        </NeonButton>
      </div>

      <TransactionTable
        kind={kind} rows={rows} currency={currency}
        onEdit={(row) => setModal(row)}
        onDelete={(id) => setRows(rows.filter((r) => r.id !== id))}
      />

      {modal && (
        <Modal title={modal === "new" ? `Add ${kind} entry` : `Edit ${kind} entry`} onClose={() => setModal(null)}>
          <TransactionForm kind={kind} initial={modal === "new" ? null : modal} onSave={handleSave} onClose={() => setModal(null)} currency={currency} />
        </Modal>
      )}
    </div>
  );
}

/* ------------------------------ INVESTMENTS MODULE ------------------------------ */
const INVESTMENT_TYPES = ["Stocks", "Mutual Funds", "ETFs", "SIPs", "Bonds", "Gold", "Crypto", "Real Estate", "Fixed Deposit"];
const TYPE_COLORS = {
  Stocks: "#00FFB3", "Mutual Funds": "#7C3AED", ETFs: "#22D3EE", SIPs: "#FACC15",
  Bonds: "#818CF8", Gold: "#FB923C", Crypto: "#F472B6", "Real Estate": "#34D399", "Fixed Deposit": "#8B8B92",
};

function InvestmentForm({ initial, onSave, onClose, currency }) {
  const [form, setForm] = useState(initial || {
    name: "", type: INVESTMENT_TYPES[0], invested: "", current: "",
    purchaseDate: new Date().toISOString().slice(0, 10), notes: "",
  });
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); onSave({ ...form, invested: Number(form.invested), current: Number(form.current) }); }}
      style={{ display: "flex", flexDirection: "column", gap: 14 }}
    >
      <Input label="Investment name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Nifty 50 Index Fund" />
      <Select label="Investment type" options={INVESTMENT_TYPES} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} />
      <div style={{ display: "flex", gap: 12 }}>
        <div style={{ flex: 1 }}><Input label={`Amount invested (${currency})`} type="number" required min="0" value={form.invested} onChange={(e) => setForm({ ...form, invested: e.target.value })} /></div>
        <div style={{ flex: 1 }}><Input label={`Current value (${currency})`} type="number" required min="0" value={form.current} onChange={(e) => setForm({ ...form, current: e.target.value })} /></div>
      </div>
      <Input label="Purchase date" type="date" required value={form.purchaseDate} onChange={(e) => setForm({ ...form, purchaseDate: e.target.value })} />
      <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
        Notes / description
        <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2}
          style={{ background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10, padding: "10px 12px", color: C.text, fontSize: 14, outline: "none", fontFamily: "inherit", resize: "vertical" }} />
      </label>
      <div style={{ display: "flex", gap: 10, marginTop: 6, justifyContent: "flex-end" }}>
        <NeonButton variant="ghost" onClick={onClose}>Cancel</NeonButton>
        <NeonButton type="submit" variant="violet">{initial ? "Save changes" : "Add investment"}</NeonButton>
      </div>
    </form>
  );
}

function InvestmentsModule({ investments, setInvestments, currency }) {
  const [modal, setModal] = useState(null);

  const totalInvested = investments.reduce((s, v) => s + v.invested, 0);
  const totalCurrent = investments.reduce((s, v) => s + v.current, 0);
  const totalPL = totalCurrent - totalInvested;
  const roi = totalInvested > 0 ? (totalPL / totalInvested) * 100 : 0;

  const allocation = useMemo(() => {
    const map = {};
    investments.forEach((v) => { map[v.type] = (map[v.type] || 0) + v.current; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [investments]);

  const handleSave = (data) => {
    if (modal && modal !== "new") {
      setInvestments(investments.map((v) => (v.id === modal.id ? { ...v, ...data } : v)));
    } else {
      setInvestments([{ id: `v${Date.now()}`, ...data }, ...investments]);
    }
    setModal(null);
  };

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label="Total invested" value={totalInvested} icon={<Wallet size={18} />} color={C.textMute} currency={currency} />
        <KpiCard label="Current value" value={totalCurrent} icon={<TrendingUp size={18} />} color={C.accent} glow currency={currency} />
        <KpiCard label="Profit / loss" value={totalPL} icon={totalPL >= 0 ? <ArrowUp size={18} /> : <ArrowDown size={18} />} color={totalPL >= 0 ? C.success : C.danger} currency={currency} />
        <GlassCard style={{ padding: "18px 20px", flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, fontWeight: 600, marginBottom: 8 }}>Overall ROI</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: roi >= 0 ? C.success : C.danger, fontFamily: "'JetBrains Mono', monospace" }}>
            {roi >= 0 ? "+" : ""}{roi.toFixed(1)}%
          </div>
        </GlassCard>
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <ChartCard title="Portfolio allocation" height={240}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={allocation} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={3}>
                {allocation.map((entry) => <Cell key={entry.name} fill={TYPE_COLORS[entry.name] || "#8B8B92"} stroke="none" />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Legend wrapperStyle={{ fontSize: 11, color: C.textMute }} iconType="circle" />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Invested vs current value" height={240}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={investments.map((v) => ({ name: v.name.split(" ").slice(0, 2).join(" "), invested: v.invested, current: v.current }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E1E1E" vertical={false} />
              <XAxis dataKey="name" stroke={C.textFaint} fontSize={10.5} tickLine={false} axisLine={false} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
              <Bar dataKey="invested" fill="#3A3A3A" radius={[6, 6, 0, 0]} />
              <Bar dataKey="current" fill={C.highlight} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <NeonButton variant="violet" onClick={() => setModal("new")}><Plus size={15} /> Add investment</NeonButton>
      </div>

      <GlassCard style={{ padding: 20 }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {["Name", "Type", "Invested", "Current value", "P/L", "ROI", ""].map((h) => (
                  <th key={h} style={{ textAlign: h === "Name" || h === "Type" ? "left" : "right", padding: "0 10px 10px", fontSize: 11.5, color: C.textFaint, fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {investments.map((v) => {
                const pl = v.current - v.invested;
                const r = v.invested > 0 ? (pl / v.invested) * 100 : 0;
                return (
                  <tr key={v.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                    <td style={{ padding: "12px 10px", fontSize: 13.5, color: C.text, fontWeight: 600 }}>{v.name}</td>
                    <td style={{ padding: "12px 10px" }}><Pill color={TYPE_COLORS[v.type]}>{v.type}</Pill></td>
                    <td style={{ padding: "12px 10px", fontSize: 13, color: C.textMute, textAlign: "right", fontFamily: "'JetBrains Mono', monospace" }}>{fmt(v.invested, currency)}</td>
                    <td style={{ padding: "12px 10px", fontSize: 13, color: C.text, textAlign: "right", fontFamily: "'JetBrains Mono', monospace" }}>{fmt(v.current, currency)}</td>
                    <td style={{ padding: "12px 10px", fontSize: 13, fontWeight: 700, textAlign: "right", color: pl >= 0 ? C.success : C.danger, fontFamily: "'JetBrains Mono', monospace" }}>{signedFmt(pl, currency)}</td>
                    <td style={{ padding: "12px 10px", fontSize: 13, fontWeight: 700, textAlign: "right", color: r >= 0 ? C.success : C.danger }}>{r >= 0 ? "+" : ""}{r.toFixed(1)}%</td>
                    <td style={{ padding: "12px 10px" }}>
                      <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                        <button onClick={() => setModal(v)} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Pencil size={14} /></button>
                        <button onClick={() => setInvestments(investments.filter((x) => x.id !== v.id))} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {modal && (
        <Modal title={modal === "new" ? "Add investment" : "Edit investment"} onClose={() => setModal(null)}>
          <InvestmentForm initial={modal === "new" ? null : modal} onSave={handleSave} onClose={() => setModal(null)} currency={currency} />
        </Modal>
      )}
    </div>
  );
}

/* ------------------------------ GOALS MODULE ------------------------------ */
function GoalForm({ initial, onSave, onClose, currency }) {
  const [form, setForm] = useState(initial || { name: "", target: "", saved: "", deadline: "" });
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); onSave({ ...form, target: Number(form.target), saved: Number(form.saved) }); }}
      style={{ display: "flex", flexDirection: "column", gap: 14 }}
    >
      <Input label="Goal name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Buy a car" />
      <div style={{ display: "flex", gap: 12 }}>
        <div style={{ flex: 1 }}><Input label={`Target amount (${currency})`} type="number" required min="0" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })} /></div>
        <div style={{ flex: 1 }}><Input label={`Currently saved (${currency})`} type="number" required min="0" value={form.saved} onChange={(e) => setForm({ ...form, saved: e.target.value })} /></div>
      </div>
      <Input label="Deadline" type="date" required value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
      <div style={{ display: "flex", gap: 10, marginTop: 6, justifyContent: "flex-end" }}>
        <NeonButton variant="ghost" onClick={onClose}>Cancel</NeonButton>
        <NeonButton type="submit" variant="primary">{initial ? "Save changes" : "Create goal"}</NeonButton>
      </div>
    </form>
  );
}

function monthsBetween(today, deadline) {
  const d1 = new Date(today), d2 = new Date(deadline);
  return Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24 * 30)));
}

function GoalCard({ goal, onEdit, onDelete, currency }) {
  const pct = (goal.saved / goal.target) * 100;
  const remaining = goal.target - goal.saved;
  const months = monthsBetween("2026-06-20", goal.deadline);
  const neededPerMonth = remaining > 0 ? remaining / months : 0;
  const isComplete = pct >= 100;
  const color = isComplete ? C.success : pct > 60 ? C.accent : pct > 30 ? C.highlight : C.danger;

  return (
    <GlassCard style={{ padding: 22, flex: "1 1 280px", minWidth: 260 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.text, marginBottom: 4 }}>{goal.name}</div>
          <div style={{ fontSize: 12, color: C.textFaint }}>Due {goal.deadline}</div>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          <button onClick={() => onEdit(goal)} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Pencil size={14} /></button>
          <button onClick={() => onDelete(goal.id)} style={{ background: "none", border: "none", color: C.textMute, cursor: "pointer", padding: 4 }}><Trash2 size={14} /></button>
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
        <span style={{ fontSize: 20, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{fmt(goal.saved, currency)}</span>
        <span style={{ fontSize: 13, color: C.textMute }}>of {fmt(goal.target, currency)}</span>
      </div>

      <ProgressBar pct={pct} color={color} />

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10 }}>
        <Pill color={color}>{Math.min(100, pct).toFixed(0)}% complete</Pill>
        {!isComplete && <span style={{ fontSize: 11.5, color: C.textFaint }}>Save {fmt(neededPerMonth, currency)}/mo to hit goal</span>}
        {isComplete && <span style={{ fontSize: 11.5, color: C.success, fontWeight: 600 }}>Goal reached 🎯</span>}
      </div>
    </GlassCard>
  );
}

function GoalsModule({ goals, setGoals, currency }) {
  const [modal, setModal] = useState(null);

  const totalTarget = goals.reduce((s, g) => s + g.target, 0);
  const totalSaved = goals.reduce((s, g) => s + g.saved, 0);
  const completed = goals.filter((g) => g.saved >= g.target).length;

  const handleSave = (data) => {
    if (modal && modal !== "new") {
      setGoals(goals.map((g) => (g.id === modal.id ? { ...g, ...data } : g)));
    } else {
      setGoals([{ id: `g${Date.now()}`, ...data }, ...goals]);
    }
    setModal(null);
  };

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label="Total saved" value={totalSaved} icon={<PiggyBank size={18} />} color={C.success} glow currency={currency} />
        <KpiCard label="Total target" value={totalTarget} icon={<Target size={18} />} color={C.highlight} currency={currency} />
        <GlassCard style={{ padding: "18px 20px", flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, fontWeight: 600, marginBottom: 8 }}>Goals completed</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: C.accent, fontFamily: "'JetBrains Mono', monospace" }}>{completed} / {goals.length}</div>
        </GlassCard>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <NeonButton variant="primary" onClick={() => setModal("new")}><Plus size={15} /> Create goal</NeonButton>
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        {goals.map((g) => (
          <GoalCard key={g.id} goal={g} currency={currency}
            onEdit={(goal) => setModal(goal)}
            onDelete={(id) => setGoals(goals.filter((x) => x.id !== id))} />
        ))}
      </div>

      {modal && (
        <Modal title={modal === "new" ? "Create savings goal" : "Edit goal"} onClose={() => setModal(null)}>
          <GoalForm initial={modal === "new" ? null : modal} onSave={handleSave} onClose={() => setModal(null)} currency={currency} />
        </Modal>
      )}
    </div>
  );
}

/* ------------------------------ AI ADVISOR MODULE ------------------------------ */
function financeSnapshot(income, expenses, investments, goals, currency) {
  const totalIncome = income.reduce((s, i) => s + i.amount, 0);
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const totalInvested = investments.reduce((s, v) => s + v.invested, 0);
  const totalCurrentVal = investments.reduce((s, v) => s + v.current, 0);
  const totalSaved = goals.reduce((s, g) => s + g.saved, 0);
  const monthlyIncomeAvg = totalIncome / 3;
  const monthlyExpenseAvg = totalExpenses / 3;

  const byCategory = {};
  expenses.forEach((e) => { byCategory[e.category] = (byCategory[e.category] || 0) + e.amount; });
  const sortedCategories = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);

  return { totalIncome, totalExpenses, totalInvested, totalCurrentVal, totalSaved, monthlyIncomeAvg, monthlyExpenseAvg, byCategory, sortedCategories };
}

function generateAdvisorReply(question, income, expenses, investments, goals, currency) {
  const q = question.toLowerCase();
  const snap = financeSnapshot(income, expenses, investments, goals, currency);
  const f = (n) => fmt(n, currency);

  if (/save.*\d|\d.*save|save more|save per month|reduce spend|cut (back|expense)/.test(q)) {
    const targetMatch = q.match(/(\d[\d,]*)/);
    const target = targetMatch ? Number(targetMatch[1].replace(/,/g, "")) : 10000;
    const top = snap.sortedCategories.slice(0, 3);
    const lines = top.map(([cat, amt]) => {
      const cutPct = cat === "Food" || cat === "Shopping" || cat === "Entertainment" ? 0.25 : 0.1;
      const cut = Math.round((amt / 3) * cutPct);
      return `- Trim ${cat} by about ${f(cut)}/month (currently averaging ${f(Math.round(amt / 3))}/month)`;
    });
    const totalPossible = top.reduce((s, [cat, amt]) => {
      const cutPct = cat === "Food" || cat === "Shopping" || cat === "Entertainment" ? 0.25 : 0.1;
      return s + Math.round((amt / 3) * cutPct);
    }, 0);
    const verdict = totalPossible >= target
      ? `Good news — these three changes alone get you to roughly ${f(totalPossible)}/month, which covers your ${f(target)} target.`
      : `These get you to about ${f(totalPossible)}/month. To close the rest of the gap toward ${f(target)}, consider automating a transfer right after each salary credit so the money never sits in your spending account.`;
    return `Here's where I'd start, based on your last few months of spending:\n\n${lines.join("\n")}\n\n${verdict}`;
  }

  if (/overspend|spending too much|am i spending|too much money/.test(q)) {
    const top = snap.sortedCategories[0];
    if (!top) return "I don't see enough expense data yet to spot a pattern — add a few more entries and ask me again.";
    const [topCat, topAmt] = top;
    const pctOfExpenses = ((topAmt / snap.totalExpenses) * 100).toFixed(0);
    const pctOfIncome = ((snap.totalExpenses / snap.totalIncome) * 100).toFixed(0);
    let verdict;
    if (pctOfIncome > 70) verdict = "Overall, your expenses are taking up a large share of your income — worth tightening up.";
    else if (pctOfIncome > 50) verdict = "Your expense ratio is reasonable but has some room to improve.";
    else verdict = "Overall your expense ratio looks healthy — you're keeping a good chunk of income free.";
    return `${topCat} is your biggest spending category — it's ${pctOfExpenses}% of your total recorded expenses. Across everything, you're spending about ${pctOfIncome}% of your income. ${verdict}`;
  }

  if (/where.*invest|invest.*bonus|invest.*next|invest.*extra/.test(q)) {
    const byType = {};
    investments.forEach((v) => { byType[v.type] = (byType[v.type] || 0) + v.current; });
    const sorted = Object.entries(byType).sort((a, b) => b[1] - a[1]);
    const lightest = [...investments].sort((a, b) => a.current - b.current)[0];
    const heaviest = sorted[0];
    return `Your portfolio is currently weighted most toward ${heaviest[0]} (${f(heaviest[1])}). If you want better diversification, consider adding to underweight areas like ${lightest ? lightest.type : "bonds or gold"}. Given a moderate risk profile, a mix of index funds and a small SIP top-up usually balances growth with stability better than concentrating in one asset type.`;
  }

  if (/health.*check|financial health|how am i doing|checkup/.test(q)) {
    const savingsRate = ((snap.totalIncome - snap.totalExpenses) / snap.totalIncome) * 100;
    const verdict = savingsRate > 30 ? "That's a strong savings rate." : savingsRate > 15 ? "That's a decent savings rate with room to grow." : "That's on the lower side — worth a closer look at fixed costs.";
    return `Quick checkup: you're saving about ${savingsRate.toFixed(0)}% of your income, your portfolio is worth ${f(snap.totalCurrentVal)} (up from ${f(snap.totalInvested)} invested), and you've put away ${f(snap.totalSaved)} toward your goals. ${verdict} Head to the Health Score tab for the full breakdown.`;
  }

  if (/net worth/.test(q)) {
    return `Your investments plus savings goals currently add up to about ${f(snap.totalCurrentVal + snap.totalSaved)}, on top of your regular cash flow. Check the Dashboard for the full net worth trend over time.`;
  }

  if (/goal|emergency fund/.test(q)) {
    const closest = [...goals].sort((a, b) => (b.saved / b.target) - (a.saved / a.target))[0];
    if (!closest) return "You don't have any savings goals set up yet — head to the Savings Goals tab to create one.";
    const pct = ((closest.saved / closest.target) * 100).toFixed(0);
    return `You're closest to completing "${closest.name}" — ${pct}% funded with ${f(closest.target - closest.saved)} left to go before ${closest.deadline}.`;
  }

  return `I can see your income, expenses, investments and goals, but I didn't quite catch what you're after. Try asking something like "how can I save more each month", "am I overspending", "where should I invest", or "give me a financial health checkup".`;
}

const STARTER_PROMPTS = [
  "How can I save ₹10,000 more per month?",
  "Am I overspending in any category?",
  "Where should I invest my next bonus?",
  "Give me a financial health checkup",
];

function Avatar({ role }) {
  if (role === "user") {
    return (
      <div style={{
        width: 30, height: 30, borderRadius: "50%", background: C.highlight,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 700, color: "#fff", flexShrink: 0,
      }}>AR</div>
    );
  }
  return (
    <div style={{
      width: 30, height: 30, borderRadius: "50%", background: `${C.accent}1A`,
      border: `1px solid ${C.accent}44`, display: "flex", alignItems: "center",
      justifyContent: "center", color: C.accent, flexShrink: 0,
    }}>
      <Bot size={15} />
    </div>
  );
}

function ChatBubble({ msg }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ display: "flex", gap: 10, flexDirection: isUser ? "row-reverse" : "row", alignSelf: isUser ? "flex-end" : "flex-start", maxWidth: "82%" }}>
      <Avatar role={msg.role} />
      <div style={{
        background: isUser ? `${C.highlight}1F` : "rgba(255,255,255,0.04)",
        border: `1px solid ${isUser ? C.highlight + "33" : C.border}`,
        borderRadius: 16,
        padding: "11px 15px",
        fontSize: 14, lineHeight: 1.55, color: C.text, whiteSpace: "pre-wrap",
      }}>
        {msg.content}
        {msg.error && (
          <div style={{ marginTop: 8, fontSize: 12, color: C.danger, display: "flex", alignItems: "center", gap: 5 }}>
            <AlertTriangle size={13} /> Couldn't reach the advisor. Try again.
          </div>
        )}
      </div>
    </div>
  );
}

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: 10, alignSelf: "flex-start" }}>
      <Avatar role="assistant" />
      <div style={{
        background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`,
        borderRadius: 16, padding: "13px 16px", display: "flex", gap: 4, alignItems: "center",
      }}>
        {[0, 1, 2].map((i) => (
          <span key={i} style={{
            width: 6, height: 6, borderRadius: "50%", background: C.accent,
            animation: `finzen-bounce 1.1s ${i * 0.15}s infinite ease-in-out`,
          }} />
        ))}
      </div>
    </div>
  );
}

function AIAdvisorModule({ income, expenses, investments, goals, currency }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = React.useRef(null);

  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  async function sendMessage(text) {
    if (!text.trim() || loading) return;
    const userMsg = { role: "user", content: text.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    // Simulate a brief thinking delay so the typing indicator feels natural,
    // then generate a reply from the user's real financial data.
    await new Promise((resolve) => setTimeout(resolve, 600 + Math.random() * 500));

    try {
      const reply = generateAdvisorReply(text, income, expenses, investments, goals, currency);
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: "I couldn't process that request.", error: true }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 18, height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{
          width: 46, height: 46, borderRadius: 14, background: `linear-gradient(135deg, ${C.accent}, ${C.highlight})`,
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
        }}>
          <Bot size={22} color="#000" />
        </div>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: C.text }}>FinZen Advisor</div>
          <div style={{ fontSize: 12.5, color: C.textMute }}>Answers based on your real income, expenses, investments and goals</div>
        </div>
      </div>

      <GlassCard style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", padding: 0, minHeight: 460 }}>
        <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
          {messages.length === 0 && (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18, textAlign: "center" }}>
              <div style={{
                width: 56, height: 56, borderRadius: 16, background: `${C.accent}14`,
                border: `1px solid ${C.accent}33`, display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <Sparkles size={24} color={C.accent} />
              </div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 4 }}>Ask me anything about your money</div>
                <div style={{ fontSize: 13, color: C.textMute, maxWidth: 360 }}>I can see your income, expenses, investments and goals — try one of these to start.</div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", maxWidth: 480 }}>
                {STARTER_PROMPTS.map((p) => (
                  <button key={p} onClick={() => sendMessage(p)} style={{
                    background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`, borderRadius: 12,
                    padding: "9px 14px", fontSize: 12.5, color: C.text, cursor: "pointer", fontFamily: "inherit",
                  }}>
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => <ChatBubble key={i} msg={m} />)}
          {loading && <TypingDots />}
        </div>

        <div style={{ borderTop: `1px solid ${C.border}`, padding: 16, display: "flex", gap: 10 }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
            placeholder="Ask about your spending, savings or investments..."
            style={{
              flex: 1, background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 12,
              padding: "12px 16px", color: C.text, fontSize: 14, outline: "none", fontFamily: "inherit",
            }}
          />
          <NeonButton variant="primary" onClick={() => sendMessage(input)} style={{ padding: "12px 16px" }}>
            <SendHorizontal size={16} />
          </NeonButton>
        </div>
      </GlassCard>

      <style>{`
        @keyframes finzen-bounce { 0%, 60%, 100% { transform: translateY(0); opacity: 0.5; } 30% { transform: translateY(-4px); opacity: 1; } }
      `}</style>
    </div>
  );
}

/* ------------------------------ BUDGET PLANNER MODULE ------------------------------ */
const BUDGET_CATEGORIES = ["Food", "Rent", "Travel", "Shopping", "Entertainment", "Bills"];

const seedBudgets = {
  Food: 8000, Rent: 28000, Travel: 6000, Shopping: 6000, Entertainment: 2000, Bills: 4000,
};

function budgetStatus(actual, budget) {
  const pct = budget > 0 ? (actual / budget) * 100 : 0;
  if (pct > 100) return { color: C.danger, label: "Over budget", pct };
  if (pct >= 80) return { color: "#FACC15", label: "Warning", pct };
  return { color: C.success, label: "On track", pct };
}

function BudgetRow({ category, budget, actual, currency, onChangeBudget }) {
  const status = budgetStatus(actual, budget);
  const diff = budget - actual;
  return (
    <GlassCard style={{ padding: "16px 20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ width: 10, height: 10, borderRadius: 3, background: CATEGORY_COLORS[category] || C.highlight, flexShrink: 0 }} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: C.text }}>{category}</span>
          <Pill color={status.color}>{status.label}</Pill>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 12, color: C.textMute }}>Budget</span>
          <input
            type="number" min="0" value={budget}
            onChange={(e) => onChangeBudget(category, Number(e.target.value))}
            style={{
              width: 96, background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 8,
              padding: "5px 8px", color: C.text, fontSize: 13, outline: "none", fontFamily: "'JetBrains Mono', monospace",
            }}
          />
        </div>
      </div>
      <ProgressBar pct={status.pct} color={status.color} />
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 12.5 }}>
        <span style={{ color: C.textMute }}>
          Spent <span style={{ color: C.text, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" }}>{fmt(actual, currency)}</span> of {fmt(budget, currency)}
        </span>
        <span style={{ color: diff >= 0 ? C.success : C.danger, fontWeight: 600 }}>
          {diff >= 0 ? `${fmt(diff, currency)} left` : `${fmt(Math.abs(diff), currency)} over`}
        </span>
      </div>
    </GlassCard>
  );
}

function BudgetPlannerModule({ expenses, currency }) {
  const [budgets, setBudgets] = useState(seedBudgets);

  const actualByCategory = useMemo(() => {
    const map = {};
    expenses.filter((e) => e.date.startsWith("2026-06")).forEach((e) => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return map;
  }, [expenses]);

  const totalBudget = Object.values(budgets).reduce((s, v) => s + v, 0);
  const totalActual = BUDGET_CATEGORIES.reduce((s, c) => s + (actualByCategory[c] || 0), 0);
  const overCount = BUDGET_CATEGORIES.filter((c) => (actualByCategory[c] || 0) > budgets[c]).length;
  const warnCount = BUDGET_CATEGORIES.filter((c) => {
    const a = actualByCategory[c] || 0;
    return a <= budgets[c] && a / budgets[c] >= 0.8;
  }).length;

  const chartData = BUDGET_CATEGORIES.map((c) => ({ name: c, budget: budgets[c], actual: actualByCategory[c] || 0 }));

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <KpiCard label="Total budget (June)" value={totalBudget} icon={<ClipboardList size={18} />} color={C.highlight} currency={currency} />
        <KpiCard label="Total actual spend" value={totalActual} icon={<ArrowUpCircle size={18} />} color={totalActual > totalBudget ? C.danger : C.accent} glow={totalActual <= totalBudget} currency={currency} />
        <GlassCard style={{ padding: "18px 20px", flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, fontWeight: 600, marginBottom: 8 }}>Categories over budget</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: overCount > 0 ? C.danger : C.success, fontFamily: "'JetBrains Mono', monospace" }}>{overCount}</div>
        </GlassCard>
        <GlassCard style={{ padding: "18px 20px", flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, fontWeight: 600, marginBottom: 8 }}>Categories near limit</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: "#FACC15", fontFamily: "'JetBrains Mono', monospace" }}>{warnCount}</div>
        </GlassCard>
      </div>

      <ChartCard title="Budget vs actual spend — June" height={260}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1E1E1E" vertical={false} />
            <XAxis dataKey="name" stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} />
            <YAxis stroke={C.textFaint} fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v / 1000}k`} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmt(v, currency)} />
            <Bar dataKey="budget" fill="#3A3A3A" radius={[6, 6, 0, 0]} />
            <Bar dataKey="actual" radius={[6, 6, 0, 0]}>
              {chartData.map((d) => (
                <Cell key={d.name} fill={budgetStatus(d.actual, d.budget).color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {BUDGET_CATEGORIES.map((c) => (
          <BudgetRow
            key={c} category={c} budget={budgets[c]} actual={actualByCategory[c] || 0} currency={currency}
            onChangeBudget={(cat, val) => setBudgets((b) => ({ ...b, [cat]: val }))}
          />
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ FINANCIAL HEALTH SCORE MODULE ------------------------------ */
function computeHealthScore(income, expenses, investments, goals) {
  const totalIncome = income.reduce((s, i) => s + i.amount, 0);
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const totalInvested = investments.reduce((s, v) => s + v.invested, 0);
  const totalCurrentVal = investments.reduce((s, v) => s + v.current, 0);
  const emergencyGoal = goals.find((g) => g.name.toLowerCase().includes("emergency"));
  const monthlyExpenseAvg = totalExpenses / 3; // approx 3 months of seed data

  const savingsRate = totalIncome > 0 ? Math.max(0, (totalIncome - totalExpenses) / totalIncome) : 0;
  const savingsScore = Math.min(100, savingsRate * 100 * 2.2);

  const expenseRatio = totalIncome > 0 ? totalExpenses / totalIncome : 1;
  const expenseScore = Math.max(0, 100 - expenseRatio * 100);

  const debtRatio = 0.06; // no debt entries in current data model — assume low fixed obligations
  const debtScore = Math.max(0, 100 - debtRatio * 400);

  const investmentRatio = totalIncome > 0 ? totalCurrentVal / totalIncome : 0;
  const investmentScore = Math.min(100, investmentRatio * 40);

  const emergencyMonths = emergencyGoal && monthlyExpenseAvg > 0 ? emergencyGoal.saved / monthlyExpenseAvg : 0;
  const emergencyScore = Math.min(100, (emergencyMonths / 6) * 100);

  const weights = { savings: 0.25, expense: 0.2, debt: 0.2, investment: 0.2, emergency: 0.15 };
  const overall = Math.round(
    savingsScore * weights.savings + expenseScore * weights.expense + debtScore * weights.debt +
    investmentScore * weights.investment + emergencyScore * weights.emergency
  );

  return {
    overall: Math.min(100, Math.max(0, overall)),
    breakdown: [
      { label: "Savings rate", score: Math.round(savingsScore), detail: `${(savingsRate * 100).toFixed(1)}% of income saved` },
      { label: "Expense ratio", score: Math.round(expenseScore), detail: `${(expenseRatio * 100).toFixed(1)}% of income spent` },
      { label: "Debt ratio", score: Math.round(debtScore), detail: "Low fixed debt obligations" },
      { label: "Investment ratio", score: Math.round(investmentScore), detail: `Portfolio worth ${investmentRatio.toFixed(1)}x monthly income` },
      { label: "Emergency fund", score: Math.round(emergencyScore), detail: `${emergencyMonths.toFixed(1)} months of expenses covered` },
    ],
  };
}

function scoreColor(score) {
  if (score >= 75) return C.success;
  if (score >= 50) return "#FACC15";
  return C.danger;
}

function HealthGauge({ score }) {
  const radius = 80, stroke = 14, circumference = Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = scoreColor(score);
  return (
    <svg width={200} height={120} viewBox="0 0 200 120">
      <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#1E1E1E" strokeWidth={stroke} strokeLinecap="round" />
      <path
        d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        strokeDasharray={circumference} strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 0.6s ease", filter: `drop-shadow(0 0 8px ${color}66)` }}
      />
      <text x="100" y="92" textAnchor="middle" fontSize="36" fontWeight="700" fill={C.text} fontFamily="'Space Grotesk', sans-serif">{score}</text>
      <text x="100" y="112" textAnchor="middle" fontSize="11" fill={C.textMute}>out of 100</text>
    </svg>
  );
}

function HealthScoreModule({ income, expenses, investments, goals, currency }) {
  const { overall, breakdown } = useMemo(() => computeHealthScore(income, expenses, investments, goals), [income, expenses, investments, goals]);

  const tier = overall >= 75 ? "Excellent" : overall >= 50 ? "Fair" : "Needs attention";

  const suggestions = breakdown
    .filter((b) => b.score < 65)
    .map((b) => {
      const tips = {
        "Savings rate": "Try automating a transfer of 20% of income on payday before you can spend it.",
        "Expense ratio": "Review your top 3 spending categories — even a 10% cut there compounds fast.",
        "Debt ratio": "Keep fixed obligations under 30% of income to stay flexible.",
        "Investment ratio": "Consider increasing your SIP amount or adding a low-cost index fund.",
        "Emergency fund": "Aim for 6 months of expenses in your emergency fund before increasing investment risk.",
      };
      return { label: b.label, tip: tips[b.label] };
    });

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <GlassCard glow style={{ padding: 24, flex: "1 1 280px", display: "flex", alignItems: "center", gap: 24 }}>
          <HealthGauge score={overall} />
          <div>
            <Pill color={scoreColor(overall)}>{tier}</Pill>
            <div style={{ fontSize: 13, color: C.textMute, marginTop: 10, maxWidth: 240 }}>
              Your financial health score blends savings rate, expense ratio, debt load, investment allocation and emergency fund coverage into one number.
            </div>
          </div>
        </GlassCard>

        <div style={{ flex: "1 1 320px", display: "flex", flexDirection: "column", gap: 10 }}>
          {breakdown.map((b) => (
            <GlassCard key={b.label} style={{ padding: "13px 18px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{b.label}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: scoreColor(b.score), fontFamily: "'JetBrains Mono', monospace" }}>{b.score}</span>
              </div>
              <ProgressBar pct={b.score} color={scoreColor(b.score)} />
              <div style={{ fontSize: 11.5, color: C.textFaint, marginTop: 5 }}>{b.detail}</div>
            </GlassCard>
          ))}
        </div>
      </div>

      <GlassCard style={{ padding: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <ShieldCheck size={18} color={C.accent} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: C.text }}>Improvement suggestions</span>
        </div>
        {suggestions.length === 0 ? (
          <div style={{ fontSize: 13.5, color: C.textMute, display: "flex", alignItems: "center", gap: 8 }}>
            <CheckCircle2 size={16} color={C.success} /> All your scores are healthy right now — keep up the habits that got you here.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {suggestions.map((s) => (
              <div key={s.label} style={{ display: "flex", gap: 10, fontSize: 13.5, color: C.textMute }}>
                <CircleAlert size={16} color="#FACC15" style={{ flexShrink: 0, marginTop: 1 }} />
                <span><strong style={{ color: C.text, fontWeight: 600 }}>{s.label}:</strong> {s.tip}</span>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
}

/* ------------------------------ FINANCIAL REPORTS MODULE ------------------------------ */
function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function toCSV(rows, headers) {
  const escape = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [headers.map(escape).join(",")];
  rows.forEach((r) => lines.push(headers.map((h) => escape(r[h] ?? "")).join(",")));
  return lines.join("\n");
}

function ReportRow({ icon, label, value, color, currency }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13.5, color: C.textMute }}>
        {icon}{label}
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color: color || C.text, fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
    </div>
  );
}

function ReportsModule({ income, expenses, investments, goals, currency }) {
  const [exporting, setExporting] = useState(null);
  const totalIncome = income.reduce((s, i) => s + i.amount, 0);
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const totalInvested = investments.reduce((s, v) => s + v.invested, 0);
  const totalCurrentVal = investments.reduce((s, v) => s + v.current, 0);
  const totalSaved = goals.reduce((s, g) => s + g.saved, 0);
  const { overall } = useMemo(() => computeHealthScore(income, expenses, investments, goals), [income, expenses, investments, goals]);
  const goalsComplete = goals.filter((g) => g.saved >= g.target).length;

  async function exportExcel() {
    setExporting("excel");
    try {
      const XLSX = await import("https://esm.sh/xlsx@0.18.5");
      const wb = XLSX.utils.book_new();
      const summary = [
        ["FinZen AI — financial report", ""], ["Generated", "2026-06-20"], [""],
        ["Total income", totalIncome], ["Total expenses", totalExpenses],
        ["Net cash flow", totalIncome - totalExpenses], ["Total invested", totalInvested],
        ["Current portfolio value", totalCurrentVal], ["Total saved toward goals", totalSaved],
        ["Financial health score", overall], ["Goals completed", `${goalsComplete} / ${goals.length}`],
      ];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summary), "Summary");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(income), "Income");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(expenses), "Expenses");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(investments), "Investments");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(goals), "Goals");
      XLSX.writeFile(wb, "finzen-report.xlsx");
    } catch (e) {
      alert("Excel export failed to load. Please try again.");
    } finally {
      setExporting(null);
    }
  }

  function exportCSV() {
    const rows = [
      ...income.map((i) => ({ type: "Income", name: i.source, category: i.category, date: i.date, amount: i.amount, desc: i.desc })),
      ...expenses.map((e) => ({ type: "Expense", name: e.name, category: e.category, date: e.date, amount: -e.amount, desc: e.desc })),
    ];
    const csv = toCSV(rows, ["type", "name", "category", "date", "amount", "desc"]);
    downloadBlob(csv, "finzen-transactions.csv", "text/csv");
  }

  function exportPDF() {
    const win = window.open("", "_blank");
    const rows = (arr, isIncome) => arr.map((r) => `<tr><td>${r[isIncome ? "source" : "name"]}</td><td>${r.category}</td><td>${r.date}</td><td style="text-align:right">${fmt(r.amount, currency)}</td></tr>`).join("");
    win.document.write(`
      <html><head><title>FinZen AI Report</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 32px; color: #111; }
        h1 { font-size: 20px; margin-bottom: 4px; } h2 { font-size: 14px; margin-top: 24px; border-bottom: 2px solid #00FFB3; padding-bottom: 6px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
        td, th { padding: 6px 8px; border-bottom: 1px solid #ddd; text-align: left; }
        .kpi { display: flex; gap: 24px; margin: 16px 0; }
        .kpi div { font-size: 12px; color: #555; } .kpi strong { display: block; font-size: 16px; color: #111; }
      </style></head><body>
      <h1>FinZen AI — financial report</h1>
      <div style="font-size:12px;color:#666">Generated 20 June 2026</div>
      <div class="kpi">
        <div>Total income<strong>${fmt(totalIncome, currency)}</strong></div>
        <div>Total expenses<strong>${fmt(totalExpenses, currency)}</strong></div>
        <div>Net cash flow<strong>${fmt(totalIncome - totalExpenses, currency)}</strong></div>
        <div>Health score<strong>${overall} / 100</strong></div>
      </div>
      <h2>Income</h2><table><tr><th>Source</th><th>Category</th><th>Date</th><th>Amount</th></tr>${rows(income, true)}</table>
      <h2>Expenses</h2><table><tr><th>Name</th><th>Category</th><th>Date</th><th>Amount</th></tr>${rows(expenses, false)}</table>
      </body></html>
    `);
    win.document.close();
    win.print();
  }

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <NeonButton variant="primary" onClick={exportExcel} style={{ opacity: exporting === "excel" ? 0.6 : 1 }}>
          <FileSpreadsheet size={15} /> {exporting === "excel" ? "Exporting..." : "Export Excel"}
        </NeonButton>
        <NeonButton variant="ghost" onClick={exportCSV}><FileDown size={15} /> Export CSV</NeonButton>
        <NeonButton variant="violet" onClick={exportPDF}><FileText size={15} /> Export PDF</NeonButton>
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <GlassCard style={{ padding: 22, flex: "1 1 320px" }}>
          <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 8 }}>Monthly report — June 2026</div>
          <ReportRow icon={<ArrowDownCircle size={15} color={C.success} />} label="Income summary" value={fmt(totalIncome, currency)} color={C.success} />
          <ReportRow icon={<ArrowUpCircle size={15} color={C.danger} />} label="Expense summary" value={fmt(totalExpenses, currency)} color={C.danger} />
          <ReportRow icon={<PiggyBank size={15} color={C.accent} />} label="Savings summary" value={fmt(totalSaved, currency)} color={C.accent} />
          <ReportRow icon={<TrendingUp size={15} color={C.highlight} />} label="Investment summary" value={fmt(totalCurrentVal, currency)} color={C.highlight} />
        </GlassCard>

        <GlassCard style={{ padding: 22, flex: "1 1 320px" }}>
          <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 8 }}>Yearly report — 2026 (YTD)</div>
          <ReportRow icon={<Landmark size={15} color={C.accent} />} label="Net worth growth" value={fmt(netWorthTrend[netWorthTrend.length - 1].value - netWorthTrend[0].value, currency)} color={C.success} />
          <ReportRow icon={<Activity size={15} color={C.accent} />} label="Financial health score" value={`${overall} / 100`} color={scoreColor(overall)} />
          <ReportRow icon={<Target size={15} color={C.highlight} />} label="Goal achievement progress" value={`${goalsComplete} / ${goals.length} complete`} />
          <ReportRow icon={<TrendingUp size={15} color={C.success} />} label="Portfolio P/L" value={signedFmt(totalCurrentVal - totalInvested, currency)} color={totalCurrentVal >= totalInvested ? C.success : C.danger} />
        </GlassCard>
      </div>
    </div>
  );
}

/* ------------------------------ FINANCE CALENDAR MODULE ------------------------------ */
const EVENT_COLORS = { income: C.success, bill: C.danger, sip: C.highlight };
const EVENT_LABELS = { income: "Income", bill: "Bill / rent", sip: "SIP / investment" };

function CalendarModule({ recurring, currency }) {
  const daysInMonth = 30;
  const firstWeekday = 1; // June 2026 starts on a Monday
  const cells = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const eventsByDay = useMemo(() => {
    const map = {};
    calendarEvents2026_06.forEach((e) => {
      const day = Number(e.date.slice(8, 10));
      map[day] = map[day] || [];
      map[day].push(e);
    });
    return map;
  }, []);

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        {Object.entries(EVENT_LABELS).map(([key, label]) => (
          <Pill key={key} color={EVENT_COLORS[key]}>{label}</Pill>
        ))}
      </div>

      <GlassCard style={{ padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button style={{ background: "none", border: `1px solid ${C.border}`, borderRadius: 8, color: C.textMute, cursor: "pointer", padding: 6 }}><ChevronLeft size={15} /></button>
            <span style={{ fontSize: 15, fontWeight: 700, color: C.text }}>June 2026</span>
            <button style={{ background: "none", border: `1px solid ${C.border}`, borderRadius: 8, color: C.textMute, cursor: "pointer", padding: 6 }}><ChevronRight size={15} /></button>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6, marginBottom: 8 }}>
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
            <div key={d} style={{ fontSize: 11, color: C.textFaint, textAlign: "center", fontWeight: 600 }}>{d}</div>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6 }}>
          {cells.map((day, idx) => (
            <div key={idx} style={{
              minHeight: 64, borderRadius: 10, padding: 6,
              background: day ? "rgba(255,255,255,0.02)" : "transparent",
              border: day ? `1px solid ${C.border}` : "none",
            }}>
              {day && (
                <>
                  <div style={{ fontSize: 11.5, color: C.textMute, marginBottom: 4 }}>{day}</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                    {(eventsByDay[day] || []).map((e, i) => (
                      <div key={i} style={{
                        fontSize: 9.5, padding: "2px 5px", borderRadius: 5, whiteSpace: "nowrap",
                        overflow: "hidden", textOverflow: "ellipsis",
                        background: `${EVENT_COLORS[e.type]}1F`, color: EVENT_COLORS[e.type], fontWeight: 600,
                      }}>{e.label}</div>
                    ))}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard style={{ padding: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <Repeat size={17} color={C.highlight} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: C.text }}>Recurring transactions</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {recurring.map((r) => (
            <div key={r.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Pill color={r.type === "income" ? C.success : r.type === "investment" ? C.highlight : C.danger}>{r.frequency}</Pill>
                <span style={{ fontSize: 13.5, color: C.text, fontWeight: 600 }}>{r.name}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                <span style={{ fontSize: 12, color: C.textFaint }}>Next: {r.nextDate}</span>
                <span style={{ fontSize: 13.5, fontWeight: 700, color: r.type === "income" ? C.success : C.text, fontFamily: "'JetBrains Mono', monospace" }}>
                  {r.type === "income" ? "+" : "-"}{fmt(r.amount, currency)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}

/* ------------------------------ GAMIFICATION MODULE ------------------------------ */
const BADGE_ICONS = { ClipboardList, TrendingUp, PiggyBank, Flame, Trophy, Star };

function levelFromXP(xp) {
  const levels = [
    { name: "Novice Saver", min: 0 }, { name: "Budget Apprentice", min: 200 },
    { name: "Saving Champion", min: 500 }, { name: "Investment Guru", min: 900 },
    { name: "Financial Master", min: 1500 },
  ];
  let current = levels[0], next = levels[1];
  for (let i = 0; i < levels.length; i++) {
    if (xp >= levels[i].min) { current = levels[i]; next = levels[i + 1] || null; }
  }
  return { current, next };
}

function RewardsModule({ income, expenses, investments, goals, currency }) {
  const streak = 12;
  const xp = 740;
  const { current, next } = levelFromXP(xp);
  const xpPct = next ? ((xp - current.min) / (next.min - current.min)) * 100 : 100;

  const challenges = [
    { label: "Keep Food spending under ₹8,000 this month", pct: 73, color: C.accent },
    { label: "Log an expense every day for 14 days straight", pct: (streak / 14) * 100, color: C.highlight },
    { label: "Add ₹15,000 to your Emergency Fund this month", pct: 60, color: C.success },
  ];

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <GlassCard glow style={{ padding: 22, flex: "1 1 260px", display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{
            width: 54, height: 54, borderRadius: 16, background: `${C.danger}1A`,
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
          }}>
            <Flame size={26} color={C.danger} />
          </div>
          <div>
            <div style={{ fontSize: 22, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{streak} days</div>
            <div style={{ fontSize: 12.5, color: C.textMute }}>Logging streak</div>
          </div>
        </GlassCard>

        <GlassCard style={{ padding: 22, flex: "1 1 320px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
            <span style={{ fontSize: 15, fontWeight: 700, color: C.text }}>{current.name}</span>
            <span style={{ fontSize: 12, color: C.textFaint }}>{xp} XP{next ? ` / ${next.min} XP` : " (max level)"}</span>
          </div>
          <ProgressBar pct={xpPct} color={C.highlight} />
          {next && <div style={{ fontSize: 11.5, color: C.textFaint, marginTop: 6 }}>{next.min - xp} XP to {next.name}</div>}
        </GlassCard>
      </div>

      <GlassCard style={{ padding: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
          <Trophy size={18} color={C.accent} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: C.text }}>Achievement badges</span>
        </div>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          {seedBadges.map((b) => {
            const Icon = BADGE_ICONS[b.icon] || Star;
            return (
              <div key={b.id} style={{
                flex: "1 1 150px", minWidth: 140, padding: 16, borderRadius: 14, textAlign: "center",
                background: b.earned ? "rgba(0,255,179,0.06)" : "rgba(255,255,255,0.02)",
                border: `1px solid ${b.earned ? C.accent + "33" : C.border}`,
                opacity: b.earned ? 1 : 0.5,
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: "50%", margin: "0 auto 10px",
                  background: b.earned ? `${C.accent}1A` : "rgba(255,255,255,0.04)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: b.earned ? C.accent : C.textFaint,
                }}>
                  <Icon size={19} />
                </div>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: C.text, marginBottom: 4 }}>{b.name}</div>
                <div style={{ fontSize: 10.5, color: C.textFaint, lineHeight: 1.4 }}>{b.desc}</div>
              </div>
            );
          })}
        </div>
      </GlassCard>

      <GlassCard style={{ padding: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
          <Zap size={17} color={C.highlight} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: C.text }}>Monthly challenges</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {challenges.map((c, i) => (
            <div key={i}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: C.text }}>{c.label}</span>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: c.color }}>{Math.min(100, Math.round(c.pct))}%</span>
              </div>
              <ProgressBar pct={c.pct} color={c.color} />
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}

/* ------------------------------ AUTH: LANDING PAGE ------------------------------ */
function LandingPage({ onGetStarted, onLogin }) {
  const features = [
    { icon: <Bot size={20} />, title: "AI Financial Advisor", desc: "Chat with an AI that knows your real numbers" },
    { icon: <TrendingUp size={20} />, title: "Investment tracking", desc: "ROI, P/L and allocation across every asset" },
    { icon: <Activity size={20} />, title: "Health score", desc: "One number for your overall financial wellness" },
    { icon: <Target size={20} />, title: "Savings goals", desc: "Forecasted, gamified, and easy to stick to" },
  ];
  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "'Inter', -apple-system, sans-serif", overflowY: "auto", position: "relative",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&family=JetBrains+Mono:wght@500;700&display=swap');
        * { box-sizing: border-box; }
      `}</style>
      <div style={{
        position: "absolute", top: "-10%", left: "50%", transform: "translateX(-50%)",
        width: 700, height: 700, borderRadius: "50%",
        background: `radial-gradient(circle, ${C.accent}14, transparent 70%)`, pointerEvents: "none",
      }} />

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "24px 48px", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, background: `linear-gradient(135deg, ${C.accent}, ${C.highlight})`,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Sparkles size={18} color="#000" />
          </div>
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 18 }}>FinZen <span style={{ color: C.accent }}>AI</span></span>
        </div>
        <NeonButton variant="ghost" onClick={onLogin}>Log in</NeonButton>
      </div>

      <div style={{ textAlign: "center", padding: "60px 24px 40px", position: "relative", zIndex: 1 }}>
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 999,
          background: `${C.accent}14`, border: `1px solid ${C.accent}33`, fontSize: 12.5, color: C.accent,
          fontWeight: 600, marginBottom: 24,
        }}>
          <Sparkles size={13} /> Powered by AI, built for your money
        </div>
        <h1 style={{
          fontFamily: "'Space Grotesk', sans-serif", fontSize: 52, fontWeight: 700, margin: "0 auto 18px",
          maxWidth: 720, lineHeight: 1.1, letterSpacing: -1,
        }}>
          Your money,<br /><span style={{ color: C.accent }}>finally</span> figured out.
        </h1>
        <p style={{ fontSize: 16, color: C.textMute, maxWidth: 480, margin: "0 auto 32px", lineHeight: 1.6 }}>
          Track income, expenses, and investments in one sleek dashboard — with an AI advisor that actually knows your numbers.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <NeonButton variant="primary" onClick={onGetStarted} style={{ padding: "13px 26px", fontSize: 14.5 }}>
            Get started free <ArrowRight size={15} />
          </NeonButton>
          <NeonButton variant="ghost" onClick={onLogin} style={{ padding: "13px 26px", fontSize: 14.5 }}>
            I have an account
          </NeonButton>
        </div>
      </div>

      <div style={{
        display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center",
        padding: "20px 48px 80px", position: "relative", zIndex: 1, maxWidth: 1000, margin: "0 auto",
      }}>
        {features.map((f) => (
          <GlassCard key={f.title} style={{ padding: 22, flex: "1 1 220px", minWidth: 200 }}>
            <IconBadge icon={f.icon} color={C.accent} />
            <div style={{ fontSize: 14.5, fontWeight: 700, marginTop: 14, marginBottom: 6 }}>{f.title}</div>
            <div style={{ fontSize: 12.5, color: C.textMute, lineHeight: 1.5 }}>{f.desc}</div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ AUTH: FORMS ------------------------------ */
function AuthShell({ children }) {
  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text, display: "flex",
      alignItems: "center", justifyContent: "center", fontFamily: "'Inter', -apple-system, sans-serif",
      padding: 24, position: "relative", overflow: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap');
        * { box-sizing: border-box; }
      `}</style>
      <div style={{
        position: "absolute", top: "-20%", right: "-10%", width: 500, height: 500, borderRadius: "50%",
        background: `radial-gradient(circle, ${C.highlight}14, transparent 70%)`, pointerEvents: "none",
      }} />
      <div style={{ width: "100%", maxWidth: 420, position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "center", marginBottom: 28 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, background: `linear-gradient(135deg, ${C.accent}, ${C.highlight})`,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Sparkles size={18} color="#000" />
          </div>
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 18 }}>FinZen <span style={{ color: C.accent }}>AI</span></span>
        </div>
        <GlassCard style={{ padding: 32 }}>{children}</GlassCard>
      </div>
    </div>
  );
}

function PasswordInput({ label, value, onChange, placeholder }) {
  const [show, setShow] = useState(false);
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
      {label}
      <div style={{ position: "relative" }}>
        <Lock size={15} style={{ position: "absolute", left: 12, top: 12, color: C.textFaint }} />
        <input
          type={show ? "text" : "password"} required value={value} onChange={onChange} placeholder={placeholder}
          style={{
            width: "100%", background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10,
            padding: "10px 38px", color: C.text, fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box",
          }}
          onFocus={(e) => (e.target.style.borderColor = C.accent)}
          onBlur={(e) => (e.target.style.borderColor = C.border)}
        />
        <button type="button" onClick={() => setShow((s) => !s)} style={{ position: "absolute", right: 10, top: 9, background: "none", border: "none", color: C.textFaint, cursor: "pointer", padding: 4 }}>
          {show ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
    </label>
  );
}

function LoginScreen({ onLogin, onSwitchToRegister, onForgot, onBack }) {
  const [email, setEmail] = useState("aryan.raj@example.com");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!email || !password) { setError("Enter both email and password."); return; }
    setError("");
    onLogin();
  }

  return (
    <AuthShell>
      <button onClick={onBack} style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, marginBottom: 18, padding: 0 }}>
        <ChevronLeft size={14} /> Back
      </button>
      <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif" }}>Welcome back</h2>
      <p style={{ margin: "0 0 24px", fontSize: 13, color: C.textMute }}>Log in to see your financial picture.</p>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12.5, color: C.textMute }}>
          Email
          <div style={{ position: "relative" }}>
            <Mail size={15} style={{ position: "absolute", left: 12, top: 12, color: C.textFaint }} />
            <input
              type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
              style={{ width: "100%", background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10, padding: "10px 12px 10px 38px", color: C.text, fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
              onFocus={(e) => (e.target.style.borderColor = C.accent)} onBlur={(e) => (e.target.style.borderColor = C.border)}
            />
          </div>
        </label>
        <PasswordInput label="Password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" />
        {error && <div style={{ fontSize: 12.5, color: C.danger, display: "flex", alignItems: "center", gap: 6 }}><AlertTriangle size={13} /> {error}</div>}
        <button type="button" onClick={onForgot} style={{ background: "none", border: "none", color: C.highlight, fontSize: 12.5, cursor: "pointer", textAlign: "right", padding: 0 }}>Forgot password?</button>
        <NeonButton type="submit" variant="primary" style={{ justifyContent: "center", padding: "12px 0", marginTop: 4 }}>Log in</NeonButton>
      </form>
      <div style={{ textAlign: "center", fontSize: 12.5, color: C.textMute, marginTop: 20 }}>
        Don't have an account?{" "}
        <button onClick={onSwitchToRegister} style={{ background: "none", border: "none", color: C.accent, fontWeight: 600, cursor: "pointer", padding: 0, fontSize: 12.5 }}>Sign up</button>
      </div>
    </AuthShell>
  );
}

function RegisterScreen({ onRegister, onSwitchToLogin, onBack }) {
  const [form, setForm] = useState({ fullName: "", username: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.fullName || !form.username || !form.email || !form.password) { setError("Please fill in every field."); return; }
    if (form.password.length < 8) { setError("Password must be at least 8 characters."); return; }
    if (form.password !== form.confirm) { setError("Passwords don't match."); return; }
    setError("");
    onRegister(form);
  }

  return (
    <AuthShell>
      <button onClick={onBack} style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, marginBottom: 18, padding: 0 }}>
        <ChevronLeft size={14} /> Back
      </button>
      <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif" }}>Create your account</h2>
      <p style={{ margin: "0 0 24px", fontSize: 13, color: C.textMute }}>Takes less than a minute.</p>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <Input label="Full name" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="Aryan Raj" />
        <Input label="Username" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="aryan.raj" />
        <Input label="Email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
        <PasswordInput label="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" />
        <PasswordInput label="Confirm password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} placeholder="Re-enter your password" />
        {error && <div style={{ fontSize: 12.5, color: C.danger, display: "flex", alignItems: "center", gap: 6 }}><AlertTriangle size={13} /> {error}</div>}
        <NeonButton type="submit" variant="primary" style={{ justifyContent: "center", padding: "12px 0", marginTop: 4 }}>Create account</NeonButton>
      </form>
      <div style={{ textAlign: "center", fontSize: 12.5, color: C.textMute, marginTop: 20 }}>
        Already have an account?{" "}
        <button onClick={onSwitchToLogin} style={{ background: "none", border: "none", color: C.accent, fontWeight: 600, cursor: "pointer", padding: 0, fontSize: 12.5 }}>Log in</button>
      </div>
    </AuthShell>
  );
}

function ForgotPasswordScreen({ onBack, onSwitchToLogin }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <AuthShell>
      <button onClick={onBack} style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, marginBottom: 18, padding: 0 }}>
        <ChevronLeft size={14} /> Back
      </button>
      {!sent ? (
        <>
          <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif" }}>Reset your password</h2>
          <p style={{ margin: "0 0 24px", fontSize: 13, color: C.textMute }}>We'll email you a link to reset it.</p>
          <form onSubmit={(e) => { e.preventDefault(); if (email) setSent(true); }} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            <NeonButton type="submit" variant="primary" style={{ justifyContent: "center", padding: "12px 0", marginTop: 4 }}>Send reset link</NeonButton>
          </form>
        </>
      ) : (
        <div style={{ textAlign: "center", padding: "10px 0" }}>
          <div style={{ width: 50, height: 50, borderRadius: "50%", background: `${C.success}1A`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
            <CheckCircle2 size={24} color={C.success} />
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 6 }}>Check your inbox</div>
          <div style={{ fontSize: 13, color: C.textMute, marginBottom: 20 }}>We sent a password reset link to {email}.</div>
          <NeonButton variant="ghost" onClick={onSwitchToLogin} style={{ justifyContent: "center", width: "100%" }}>Back to log in</NeonButton>
        </div>
      )}
    </AuthShell>
  );
}

/* ------------------------------ PROFILE MODULE ------------------------------ */
function ProfileModule({ user, setUser, currency }) {
  const [form, setForm] = useState(user);
  const [saved, setSaved] = useState(false);

  function handleSave(e) {
    e.preventDefault();
    setUser(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  }

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20, maxWidth: 720 }}>
      <GlassCard style={{ padding: 26 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 24 }}>
          <div style={{ position: "relative" }}>
            <div style={{
              width: 68, height: 68, borderRadius: "50%", background: C.highlight,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 700, color: "#fff",
            }}>{form.avatarInitials}</div>
            <button style={{
              position: "absolute", bottom: -2, right: -2, width: 24, height: 24, borderRadius: "50%",
              background: C.accent, border: `2px solid ${C.bg}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
            }}>
              <Camera size={12} color="#000" />
            </button>
          </div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 700, color: C.text }}>{form.fullName}</div>
            <div style={{ fontSize: 13, color: C.textMute }}>@{form.username}</div>
          </div>
        </div>

        <form onSubmit={handleSave} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 200px" }}><Input label="Full name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
            <div style={{ flex: "1 1 200px" }}><Input label="Username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
          </div>
          <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 140px" }}><Input label="Age" type="number" value={form.age} onChange={(e) => setForm({ ...form, age: Number(e.target.value) })} /></div>
            <div style={{ flex: "1 1 220px" }}><Input label="Occupation" value={form.occupation} onChange={(e) => setForm({ ...form, occupation: e.target.value })} /></div>
          </div>
          <Input label={`Monthly income goal (${currency})`} type="number" value={form.monthlyIncomeGoal} onChange={(e) => setForm({ ...form, monthlyIncomeGoal: Number(e.target.value) })} />
          <Input label="Financial goal" value={form.financialGoal} onChange={(e) => setForm({ ...form, financialGoal: e.target.value })} placeholder="e.g. Buy a house in 5 years" />
          <Select label="Risk profile" options={["Conservative", "Moderate", "Aggressive"]} value={form.riskProfile} onChange={(e) => setForm({ ...form, riskProfile: e.target.value })} />

          <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6 }}>
            <NeonButton type="submit" variant="primary">Save changes</NeonButton>
            {saved && <span style={{ fontSize: 12.5, color: C.success, display: "flex", alignItems: "center", gap: 5 }}><Check size={14} /> Profile updated</span>}
          </div>
        </form>
      </GlassCard>
    </div>
  );
}

/* ------------------------------ SETTINGS MODULE ------------------------------ */
function ToggleSwitch({ checked, onChange }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      style={{
        width: 42, height: 24, borderRadius: 999, border: "none", cursor: "pointer", position: "relative",
        background: checked ? C.accent : "#2A2A2A", transition: "background 0.2s ease", flexShrink: 0,
      }}
    >
      <span style={{
        position: "absolute", top: 3, left: checked ? 21 : 3, width: 18, height: 18, borderRadius: "50%",
        background: checked ? "#000" : "#FFF", transition: "left 0.2s ease",
      }} />
    </button>
  );
}

function SettingsRow({ icon, label, desc, control }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 0", borderBottom: `1px solid ${C.border}`, gap: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <IconBadge icon={icon} color={C.highlight} />
        <div>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: C.text }}>{label}</div>
          {desc && <div style={{ fontSize: 12, color: C.textFaint, marginTop: 2 }}>{desc}</div>}
        </div>
      </div>
      {control}
    </div>
  );
}

function SettingsModule({ currency, setCurrency, darkMode, setDarkMode, onLogout }) {
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifPush, setNotifPush] = useState(true);
  const [notifBudget, setNotifBudget] = useState(true);
  const [sessions] = useState([
    { device: "MacBook Pro — Chrome", location: "Bengaluru, IN", current: true },
    { device: "iPhone 15 — FinZen App", location: "Bengaluru, IN", current: false },
  ]);

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20, maxWidth: 720 }}>
      <GlassCard style={{ padding: 22 }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 4 }}>Appearance</div>
        <SettingsRow
          icon={darkMode ? <Moon size={17} /> : <Sun size={17} />}
          label="Dark mode" desc="Default theme is dark — toggle to switch to light"
          control={<ToggleSwitch checked={darkMode} onChange={setDarkMode} />}
        />
        <SettingsRow
          icon={<Globe size={17} />}
          label="Currency" desc="Used across all amounts in the app"
          control={
            <select value={currency} onChange={(e) => setCurrency(e.target.value)} style={{
              background: "#0A0A0A", border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 12px",
              color: C.text, fontSize: 13, fontFamily: "inherit", outline: "none",
            }}>
              {["INR", "USD", "EUR", "GBP"].map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          }
        />
      </GlassCard>

      <GlassCard style={{ padding: 22 }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 4 }}>Notifications</div>
        <SettingsRow icon={<Mail size={17} />} label="Email alerts" desc="Monthly reports and important updates" control={<ToggleSwitch checked={notifEmail} onChange={setNotifEmail} />} />
        <SettingsRow icon={<Smartphone size={17} />} label="Push notifications" desc="Real-time alerts on your device" control={<ToggleSwitch checked={notifPush} onChange={setNotifPush} />} />
        <SettingsRow icon={<AlertTriangle size={17} />} label="Budget overruns" desc="Notify when a category goes over budget" control={<ToggleSwitch checked={notifBudget} onChange={setNotifBudget} />} />
      </GlassCard>

      <GlassCard style={{ padding: 22 }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 4 }}>Security</div>
        <SettingsRow icon={<KeyRound size={17} />} label="Change password" desc="Last changed 3 months ago" control={<NeonButton variant="ghost" style={{ padding: "7px 12px", fontSize: 12.5 }}>Update</NeonButton>} />
        <div style={{ paddingTop: 14 }}>
          <div style={{ fontSize: 12.5, color: C.textMute, marginBottom: 10 }}>Active sessions</div>
          {sessions.map((s, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Smartphone size={14} color={C.textFaint} />
                <div>
                  <div style={{ fontSize: 13, color: C.text }}>{s.device}</div>
                  <div style={{ fontSize: 11, color: C.textFaint }}>{s.location}</div>
                </div>
              </div>
              {s.current ? <Pill color={C.success}>This device</Pill> : <button style={{ background: "none", border: "none", color: C.danger, fontSize: 12, cursor: "pointer" }}>Sign out</button>}
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard style={{ padding: 22, border: `1px solid ${C.danger}33` }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, color: C.text, marginBottom: 4 }}>Account</div>
        <SettingsRow icon={<LogOut size={17} />} label="Log out" desc="End your session on this device" control={<NeonButton variant="danger" onClick={onLogout} style={{ padding: "7px 12px", fontSize: 12.5 }}>Log out</NeonButton>} />
      </GlassCard>
    </div>
  );
}

/* ------------------------------ AUTHENTICATED APP SHELL ------------------------------ */
function AppShell({ user, setUser, onLogout }) {
  const [active, setActive] = useState("dashboard");
  const [currency, setCurrency] = useState("INR");
  const [darkMode, setDarkMode] = useState(true);
  const [income, setIncome] = useState(seedIncome);
  const [expenses, setExpenses] = useState(seedExpenses);
  const [investments, setInvestments] = useState(seedInvestments);
  const [goals, setGoals] = useState(seedGoals);
  const [recurring] = useState(seedRecurring);

  const titles = {
    dashboard: ["Dashboard", "Your full financial picture, at a glance"],
    income: ["Income", "Track every rupee coming in"],
    expenses: ["Expenses", "See where your money is going"],
    investments: ["Investments", "Monitor your portfolio performance"],
    goals: ["Savings goals", "Stay on track toward what matters"],
    budget: ["Budget planner", "Set limits, track actuals, stay disciplined"],
    calendar: ["Finance calendar", "Salary dates, bills, SIPs and recurring transactions"],
    health: ["Financial health score", "One number that sums up how you're doing"],
    reports: ["Financial reports", "Monthly and yearly summaries, ready to export"],
    rewards: ["Rewards", "Streaks, badges and challenges that keep you on track"],
    advisor: ["AI Advisor", "Personalized guidance from your real numbers"],
    profile: ["Profile", "Your personal and financial details"],
    settings: ["Settings", "Manage preferences, notifications and security"],
  };

  return (
    <div style={{
      display: "flex", width: "100%", height: "100vh", background: C.bg,
      fontFamily: "'Inter', -apple-system, sans-serif", color: C.text, overflow: "hidden",
      position: "relative",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&family=JetBrains+Mono:wght@500;700&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: #2A2A2A; border-radius: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        select option { background: #0A0A0A; }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(0.7); }
      `}</style>

      <Sidebar active={active} setActive={setActive} currency={currency} setCurrency={setCurrency} user={user} onLogout={onLogout} />

      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <Topbar title={titles[active][0]} subtitle={titles[active][1]} expenses={expenses} goals={goals} investments={investments} />
        <div style={{ flex: 1, overflowY: "auto" }}>
          {active === "dashboard" && <Dashboard income={income} expenses={expenses} investments={investments} goals={goals} currency={currency} />}
          {active === "income" && <IncomeExpenseModule kind="income" rows={income} setRows={setIncome} currency={currency} />}
          {active === "expenses" && <IncomeExpenseModule kind="expenses" rows={expenses} setRows={setExpenses} currency={currency} />}
          {active === "investments" && <InvestmentsModule investments={investments} setInvestments={setInvestments} currency={currency} />}
          {active === "goals" && <GoalsModule goals={goals} setGoals={setGoals} currency={currency} />}
          {active === "budget" && <BudgetPlannerModule expenses={expenses} currency={currency} />}
          {active === "calendar" && <CalendarModule recurring={recurring} currency={currency} />}
          {active === "health" && <HealthScoreModule income={income} expenses={expenses} investments={investments} goals={goals} currency={currency} />}
          {active === "reports" && <ReportsModule income={income} expenses={expenses} investments={investments} goals={goals} currency={currency} />}
          {active === "rewards" && <RewardsModule income={income} expenses={expenses} investments={investments} goals={goals} currency={currency} />}
          {active === "advisor" && <AIAdvisorModule income={income} expenses={expenses} investments={investments} goals={goals} currency={currency} />}
          {active === "profile" && <ProfileModule user={user} setUser={setUser} currency={currency} />}
          {active === "settings" && <SettingsModule currency={currency} setCurrency={setCurrency} darkMode={darkMode} setDarkMode={setDarkMode} onLogout={onLogout} />}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ ROOT APP (AUTH GATE) ------------------------------ */
export default function FinZenApp() {
  const [screen, setScreen] = useState("landing"); // landing | login | register | forgot | app
  const [user, setUser] = useState(seedUser);

  if (screen === "app") {
    return <AppShell user={user} setUser={setUser} onLogout={() => setScreen("landing")} />;
  }
  if (screen === "login") {
    return (
      <LoginScreen
        onLogin={() => setScreen("app")}
        onSwitchToRegister={() => setScreen("register")}
        onForgot={() => setScreen("forgot")}
        onBack={() => setScreen("landing")}
      />
    );
  }
  if (screen === "register") {
    return (
      <RegisterScreen
        onRegister={(form) => {
          setUser((u) => ({ ...u, fullName: form.fullName, username: form.username, email: form.email, avatarInitials: form.fullName.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "U" }));
          setScreen("app");
        }}
        onSwitchToLogin={() => setScreen("login")}
        onBack={() => setScreen("landing")}
      />
    );
  }
  if (screen === "forgot") {
    return <ForgotPasswordScreen onBack={() => setScreen("login")} onSwitchToLogin={() => setScreen("login")} />;
  }
  return <LandingPage onGetStarted={() => setScreen("register")} onLogin={() => setScreen("login")} />;
}
